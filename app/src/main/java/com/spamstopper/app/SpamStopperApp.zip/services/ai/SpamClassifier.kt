package com.spamstopper.app.services.ai

import android.util.Log
import com.spamstopper.app.data.model.CallCategory
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Clasificador de llamadas spam
 *
 * Analiza transcripción y determina si es spam basándose en:
 * - Palabras clave
 * - Patrones de telemarketing
 * - Estructura de frases
 */
@Singleton
class SpamClassifier @Inject constructor() {

    companion object {
        private const val TAG = "SpamClassifier"

        // Palabras clave de spam por categoría
        private val TELEMARKETING_KEYWORDS = setOf(
            "oferta", "promoción", "vendemos", "descuento", "gratis",
            "oportunidad única", "llamamos para ofrecerle", "interesa",
            "propuesta comercial", "rebaja", "ahorro"
        )

        private val INSURANCE_KEYWORDS = setOf(
            "seguro", "póliza", "aseguradora", "cobertura",
            "protección", "indemnización", "siniestro"
        )

        private val LOTTERY_KEYWORDS = setOf(
            "premio", "ganador", "sorteo", "millonario", "lotería",
            "afortunado", "ha sido seleccionado", "felicidades"
        )

        private val UTILITIES_KEYWORDS = setOf(
            "factura", "luz", "gas", "suministro", "compañía eléctrica",
            "tarifa", "consumo", "electricidad", "energía"
        )

        private val REAL_ESTATE_KEYWORDS = setOf(
            "vivienda", "piso", "inversión", "inmueble", "hipoteca",
            "comprar casa", "propiedad", "apartamento"
        )

        private val SURVEYS_KEYWORDS = setOf(
            "encuesta", "opinión", "valoración", "satisfacción",
            "minutos de su tiempo", "responder unas preguntas"
        )

        private val RELIGIOUS_KEYWORDS = setOf(
            "congregación", "iglesia", "testimonio", "palabra de dios",
            "salvación", "biblia", "evangelio"
        )

        private val GENERIC_SPAM_PATTERNS = setOf(
            "dueño de la línea", "propietario", "titular de la vivienda",
            "responsable del hogar", "quien toma las decisiones"
        )
    }

    /**
     * Clasifica una transcripción en categoría de spam
     *
     * @param transcription Texto transcrito
     * @return Categoría detectada
     */
    fun classify(transcription: String): CallCategory {
        if (transcription.isBlank()) {
            Log.d(TAG, "⚠️ Transcripción vacía")
            return CallCategory.ERROR_NO_AUDIO
        }

        val text = transcription.lowercase().trim()
        Log.d(TAG, "🔍 Analizando: $text")

        // Verificar cada categoría
        return when {
            // Telemarketing
            containsAny(text, TELEMARKETING_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: TELEMARKETING")
                CallCategory.SPAM_TELEMARKETING
            }

            // Seguros
            containsAny(text, INSURANCE_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: SEGUROS")
                CallCategory.SPAM_INSURANCE
            }

            // Sorteos/Premios
            containsAny(text, LOTTERY_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: SORTEOS")
                CallCategory.SPAM_LOTTERY
            }

            // Utilities
            containsAny(text, UTILITIES_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: SUMINISTROS")
                CallCategory.SPAM_UTILITIES
            }

            // Inmobiliaria
            containsAny(text, REAL_ESTATE_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: INMOBILIARIA")
                CallCategory.SPAM_REAL_ESTATE
            }

            // Encuestas
            containsAny(text, SURVEYS_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: ENCUESTAS")
                CallCategory.SPAM_SURVEYS
            }

            // Religioso
            containsAny(text, RELIGIOUS_KEYWORDS) -> {
                Log.d(TAG, "🚫 Detectado: RELIGIOSO")
                CallCategory.SPAM_RELIGIOUS
            }

            // Patrones genéricos de spam
            containsAny(text, GENERIC_SPAM_PATTERNS) -> {
                Log.d(TAG, "🚫 Detectado: SPAM GENÉRICO")
                CallCategory.SPAM_GENERIC
            }

            // Si no es spam claro, marcar como sospechoso
            else -> {
                Log.d(TAG, "🤔 No detectado como spam claro")
                CallCategory.SUSPICIOUS_UNKNOWN
            }
        }
    }

    /**
     * Verifica si el texto contiene alguna palabra clave
     */
    private fun containsAny(text: String, keywords: Set<String>): Boolean {
        return keywords.any { keyword ->
            text.contains(keyword, ignoreCase = true)
        }
    }

    /**
     * Calcula score de confianza (0.0 a 1.0)
     *
     * @return Score donde 1.0 = 100% seguro que es spam
     */
    fun getConfidenceScore(transcription: String, category: CallCategory): Float {
        if (!category.isSpam()) return 0f

        val text = transcription.lowercase()
        var score = 0f
        var matches = 0

        // Contar coincidencias según categoría
        val keywords = when (category) {
            CallCategory.SPAM_TELEMARKETING -> TELEMARKETING_KEYWORDS
            CallCategory.SPAM_INSURANCE -> INSURANCE_KEYWORDS
            CallCategory.SPAM_LOTTERY -> LOTTERY_KEYWORDS
            CallCategory.SPAM_UTILITIES -> UTILITIES_KEYWORDS
            CallCategory.SPAM_REAL_ESTATE -> REAL_ESTATE_KEYWORDS
            CallCategory.SPAM_SURVEYS -> SURVEYS_KEYWORDS
            CallCategory.SPAM_RELIGIOUS -> RELIGIOUS_KEYWORDS
            else -> GENERIC_SPAM_PATTERNS
        }

        keywords.forEach { keyword ->
            if (text.contains(keyword, ignoreCase = true)) {
                matches++
            }
        }

        // Score basado en número de coincidencias
        score = when {
            matches >= 3 -> 0.95f // Muy seguro
            matches == 2 -> 0.80f // Bastante seguro
            matches == 1 -> 0.60f // Probable
            else -> 0.30f // Incierto
        }

        return score
    }
}