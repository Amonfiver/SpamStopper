package com.spamstopper.app.service

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.telecom.Connection
import android.telecom.ConnectionRequest
import android.telecom.ConnectionService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

/**
 * SpamStopperConnectionService - Gestiona conexiones de llamadas salientes
 *
 * Este servicio se encarga de:
 * - Crear conexiones para llamadas salientes
 * - Gestionar el estado de las conexiones
 * - Configurar audio para llamadas
 */
class SpamStopperConnectionService : ConnectionService() {

    private var audioManager: AudioManager? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        fun getPhoneAccountHandle(context: Context): PhoneAccountHandle {
            val componentName = ComponentName(
                context,
                SpamStopperConnectionService::class.java
            )
            return PhoneAccountHandle(
                componentName,
                "SpamStopperAccount"
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        android.util.Log.d("ConnectionService", "🔌 Service creado")
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onCreateOutgoingConnection(
        connectionManagerPhoneAccount: PhoneAccountHandle?,
        request: ConnectionRequest?
    ): Connection? {

        android.util.Log.d("ConnectionService", "📞 Creando conexión saliente")

        val phoneNumber = request?.address

        if (phoneNumber == null) {
            android.util.Log.e("ConnectionService", "❌ No se pudo obtener número")
            return Connection.createFailedConnection(
                android.telecom.DisconnectCause(android.telecom.DisconnectCause.ERROR)
            )
        }

        android.util.Log.d("ConnectionService", "📱 Número: ${phoneNumber.schemeSpecificPart}")

        val connection = SpamStopperConnection(this, phoneNumber)

        connection.setConnectionProperties(Connection.PROPERTY_SELF_MANAGED)
        connection.setAudioModeIsVoip(true)
        connection.setAddress(phoneNumber, TelecomManager.PRESENTATION_ALLOWED)
        connection.setCallerDisplayName(
            phoneNumber.schemeSpecificPart,
            TelecomManager.PRESENTATION_ALLOWED
        )

        android.util.Log.d("ConnectionService", "✅ Conexión creada")

        return connection
    }

    override fun onCreateIncomingConnection(
        connectionManagerPhoneAccount: PhoneAccountHandle?,
        request: ConnectionRequest?
    ): Connection? {
        android.util.Log.d("ConnectionService", "📞 onCreateIncomingConnection (no implementado)")
        return null
    }

    /**
     * Clase interna que representa una conexión activa
     */
    inner class SpamStopperConnection(
        private val context: Context,
        private val phoneNumber: Uri
    ) : Connection() {

        init {
            android.util.Log.d("SpamStopperConnection", "🔌 Constructor")

            connectionProperties = PROPERTY_SELF_MANAGED
            audioModeIsVoip = true

            setActive()
            android.util.Log.d("SpamStopperConnection", "📞 Conexión marcada como ACTIVE")

            setupAudio()
        }

        private fun setupAudio() {
            try {
                android.util.Log.d("SpamStopperConnection", "🔊 Configurando audio...")

                audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
                android.util.Log.d("SpamStopperConnection", "✅ Modo audio: MODE_IN_COMMUNICATION")

                val maxVolume = audioManager?.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL) ?: 15
                audioManager?.setStreamVolume(
                    AudioManager.STREAM_VOICE_CALL,
                    maxVolume,
                    0
                )
                android.util.Log.d("SpamStopperConnection", "✅ Volumen configurado: $maxVolume")

            } catch (e: Exception) {
                android.util.Log.e("SpamStopperConnection", "❌ Error configurando audio", e)
            }
        }

        override fun onStateChanged(state: Int) {
            super.onStateChanged(state)
            val stateName = when (state) {
                STATE_NEW -> "NEW"
                STATE_RINGING -> "RINGING"
                STATE_DIALING -> "DIALING"
                STATE_ACTIVE -> "ACTIVE"
                STATE_HOLDING -> "HOLDING"
                STATE_DISCONNECTED -> "DISCONNECTED"
                else -> "UNKNOWN($state)"
            }
            android.util.Log.d("SpamStopperConnection", "📞 Estado: $stateName")
        }

        override fun onDisconnect() {
            android.util.Log.d("SpamStopperConnection", "📵 onDisconnect")
            setDisconnected(android.telecom.DisconnectCause(android.telecom.DisconnectCause.LOCAL))
            destroy()
        }

        override fun onAbort() {
            android.util.Log.d("SpamStopperConnection", "📵 onAbort")
            setDisconnected(android.telecom.DisconnectCause(android.telecom.DisconnectCause.CANCELED))
            destroy()
        }

        override fun onAnswer() {
            android.util.Log.d("SpamStopperConnection", "📞 onAnswer")
            setActive()
        }

        override fun onReject() {
            android.util.Log.d("SpamStopperConnection", "📵 onReject")
            setDisconnected(android.telecom.DisconnectCause(android.telecom.DisconnectCause.REJECTED))
            destroy()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        android.util.Log.d("ConnectionService", "🔴 Service destruido")

        audioManager?.mode = AudioManager.MODE_NORMAL
        audioManager = null

        handler.removeCallbacksAndMessages(null)
    }
}