package com.spamstopper.app.di

import android.content.Context
import com.spamstopper.app.services.ai.VoskSTTEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AIModule {

    @Provides
    @Singleton
    fun provideVoskSTTEngine(
        @ApplicationContext context: Context
    ): VoskSTTEngine {
        return VoskSTTEngine(context)
    }
}