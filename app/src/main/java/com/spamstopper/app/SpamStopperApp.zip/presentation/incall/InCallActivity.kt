package com.spamstopper.app.presentation.incall

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.spamstopper.app.ui.theme.SpamStopperTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * InCallActivity - Pantalla de llamada en curso
 *
 * Se inicia desde CallManager cuando se realiza una llamada
 */
@AndroidEntryPoint
class InCallActivity : ComponentActivity() {

    private val viewModel: InCallViewModel by viewModels()

    companion object {
        const val EXTRA_PHONE_NUMBER = "phone_number"
        const val EXTRA_CONTACT_NAME = "contact_name"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Obtener datos de la llamada
        val phoneNumber = intent.getStringExtra(EXTRA_PHONE_NUMBER) ?: ""
        val contactName = intent.getStringExtra(EXTRA_CONTACT_NAME)

        // Inicializar llamada
        viewModel.initCall(phoneNumber, contactName)

        setContent {
            SpamStopperTheme {
                val callState by viewModel.callState.collectAsState()

                InCallScreen(
                    callState = callState,
                    formattedDuration = viewModel.getFormattedDuration(),
                    onSpeakerToggle = {
                        viewModel.toggleSpeaker()
                    },
                    onMuteToggle = {
                        viewModel.toggleMute()
                    },
                    onEndCall = {
                        viewModel.endCall()
                        finish()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Asegurar que la llamada se finaliza al cerrar
        if (!isFinishing) {
            viewModel.endCall()
        }
    }
}