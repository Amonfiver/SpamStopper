package com.spamstopper.app.presentation.history

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spamstopper.app.data.database.BlockedCallDao
import com.spamstopper.app.data.database.entities.BlockedCall
import com.spamstopper.app.data.model.CallCategory
import com.spamstopper.app.domain.CallManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * ============================================================================
 * HistoryViewModel.kt - ViewModel para historial de llamadas
 * ============================================================================
 *
 * PROPÓSITO:
 * Gestiona el estado y la lógica de negocio para la pantalla de historial.
 * Combina datos de la base de datos local (BlockedCall) con el historial
 * del sistema (CallLog) para mostrar una vista unificada.
 *
 * FUNCIONALIDADES:
 * - Cargar y filtrar historial de llamadas analizadas
 * - Permitir marcar/corregir clasificaciones
 * - Devolver llamada a un número
 * - Gestionar caché de contactos
 *
 * FUENTES DE DATOS:
 * - BlockedCallDao: Llamadas analizadas por SpamStopper
 * - CallLog del sistema: Historial general (para referencia)
 * - ContactsRepository: Nombres de contactos
 *
 * ACTUALIZADO: Enero 2026 - Integración con nuevo sistema de etiquetado
 * ============================================================================
 */

@HiltViewModel
class HistoryViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val blockedCallDao: BlockedCallDao,
    private val callManager: CallManager
) : ViewModel() {

    companion object {
        private const val TAG = "HistoryViewModel"
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ESTADO
    // ═══════════════════════════════════════════════════════════════════════

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    // Flow de llamadas desde la base de datos
    val blockedCalls: StateFlow<List<BlockedCall>> = blockedCallDao.getAllFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Caché de contactos
    private val contactsCache = mutableMapOf<String, String>()

    // ═══════════════════════════════════════════════════════════════════════
    // INICIALIZACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    init {
        loadContactsCache()
        observeBlockedCalls()
    }

    private fun observeBlockedCalls() {
        viewModelScope.launch {
            blockedCalls.collect { calls ->
                _uiState.update { state ->
                    state.copy(
                        calls = calls,
                        isLoading = false,
                        totalCalls = calls.size,
                        blockedCount = calls.count { it.wasBlocked },
                        allowedCount = calls.count { !it.wasBlocked },
                        spamCount = calls.count { it.isEffectivelySpam() },
                        legitimateCount = calls.count { it.isEffectivelyLegitimate() }
                    )
                }

                android.util.Log.d(TAG, "📋 Historial actualizado: ${calls.size} llamadas")
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CACHÉ DE CONTACTOS
    // ═══════════════════════════════════════════════════════════════════════

    private fun loadContactsCache() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!hasContactsPermission()) {
                    android.util.Log.w(TAG, "⚠️ Sin permiso READ_CONTACTS")
                    return@launch
                }

                val cursor = context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                    ),
                    null, null, null
                )

                cursor?.use {
                    val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)

                    while (it.moveToNext()) {
                        val number = it.getString(numberIndex)?.replace(Regex("[^0-9+]"), "")
                        val name = it.getString(nameIndex)

                        if (!number.isNullOrBlank() && !name.isNullOrBlank()) {
                            contactsCache[number] = name
                            // También guardar últimos 9 dígitos para matching flexible
                            if (number.length >= 9) {
                                contactsCache[number.takeLast(9)] = name
                            }
                        }
                    }
                }

                android.util.Log.d(TAG, "📇 Contactos cargados: ${contactsCache.size}")

            } catch (e: Exception) {
                android.util.Log.e(TAG, "❌ Error cargando contactos: ${e.message}")
            }
        }
    }

    fun getContactName(phoneNumber: String): String? {
        val normalized = phoneNumber.replace(Regex("[^0-9+]"), "")
        return contactsCache[normalized]
            ?: contactsCache[normalized.takeLast(9)]
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ACCIONES DEL USUARIO
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Llama de vuelta a un número
     */
    fun callBack(call: BlockedCall) {
        viewModelScope.launch {
            android.util.Log.d(TAG, "📞 Llamando a: ${call.phoneNumber}")
            callManager.makeCall(call.phoneNumber, call.contactName)
        }
    }

    /**
     * Marca una llamada como spam (corrección del usuario)
     */
    fun markAsSpam(call: BlockedCall) {
        viewModelScope.launch(Dispatchers.IO) {
            android.util.Log.d(TAG, "🚫 Marcando como spam: ${call.phoneNumber}")

            val updated = call.copy(
                markedByUser = true,
                userCorrectedCategory = CallCategory.SPAM_GENERIC
            )

            blockedCallDao.update(updated)

            // TODO: Añadir a lista negra para bloqueo futuro

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(snackbarMessage = "✅ Marcada como spam") }
            }
        }
    }

    /**
     * Marca una llamada como legítima (corrección del usuario)
     */
    fun markAsLegitimate(call: BlockedCall) {
        viewModelScope.launch(Dispatchers.IO) {
            android.util.Log.d(TAG, "✅ Marcando como legítima: ${call.phoneNumber}")

            val updated = call.copy(
                markedByUser = true,
                userCorrectedCategory = CallCategory.LEGITIMATE_HUMAN
            )

            blockedCallDao.update(updated)

            // TODO: Añadir a lista blanca para permitir futuras llamadas

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(snackbarMessage = "✅ Marcada como legítima") }
            }
        }
    }

    /**
     * Elimina una llamada del historial
     */
    fun deleteCall(call: BlockedCall) {
        viewModelScope.launch(Dispatchers.IO) {
            android.util.Log.d(TAG, "🗑️ Eliminando: ${call.phoneNumber}")
            blockedCallDao.delete(call)

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(snackbarMessage = "✅ Llamada eliminada") }
            }
        }
    }

    /**
     * Limpia todo el historial
     */
    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            android.util.Log.d(TAG, "🗑️ Limpiando historial completo")
            blockedCallDao.deleteAll()

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(snackbarMessage = "✅ Historial limpiado") }
            }
        }
    }

    /**
     * Recarga el historial
     */
    fun refresh() {
        _uiState.update { it.copy(isLoading = true) }
        loadContactsCache()
        // El flow de blockedCalls se actualizará automáticamente
    }

    /**
     * Limpia el mensaje del snackbar
     */
    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PERMISOS
    // ═══════════════════════════════════════════════════════════════════════

    private fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasCallLogPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED
    }
}

/**
 * Estado de la UI del historial
 */
data class HistoryUiState(
    val calls: List<BlockedCall> = emptyList(),
    val isLoading: Boolean = true,
    val snackbarMessage: String? = null,
    val totalCalls: Int = 0,
    val blockedCount: Int = 0,
    val allowedCount: Int = 0,
    val spamCount: Int = 0,
    val legitimateCount: Int = 0
)
