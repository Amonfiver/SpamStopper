package com.spamstopper.app.service

import android.content.Context
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.InCallService
import com.spamstopper.app.audio.AudioAnalyzer
import com.spamstopper.app.domain.EmergencyKeywordDetector
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * SpamInCallService - Servicio de interceptación y análisis
 *
 * Flujo:
 * 1. Detectar llamada entrante
 * 2. Verificar si es contacto → Pasar
 * 3. Auto-contestar si está activado
 * 4. Capturar audio (12 seg máx)
 * 5. Detectar pitidos de robot
 * 6. Transcribir con STT
 * 7. Detectar keywords de emergencia
 * 8. Clasificar: SPAM/ROBOT/HUMANO
 * 9. Colgar o pasar al usuario
 */
@AndroidEntryPoint
class SpamInCallService : InCallService() {

    @Inject
    lateinit var emergencyDetector: EmergencyKeywordDetector

    private var currentCall: Call? = null
    private val handler = Handler(Looper.getMainLooper())
    private var audioManager: AudioManager? = null
    private var ringtone: Ringtone? = null
    private var hasProcessedCall = false

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call?, state: Int) {
            super.onStateChanged(call, state)

            val stateName = when (state) {
                Call.STATE_NEW -> "NEW"
                Call.STATE_RINGING -> "RINGING"
                Call.STATE_ACTIVE -> "ACTIVE"
                Call.STATE_DISCONNECTED -> "DISCONNECTED"
                else -> "UNKNOWN($state)"
            }

            android.util.Log.d("SpamInCallService", "═══════════════════════════════")
            android.util.Log.d("SpamInCallService", "📞 CAMBIO DE ESTADO: $stateName")
            android.util.Log.d("SpamInCallService", "═══════════════════════════════")

            when (state) {
                Call.STATE_RINGING -> handleRingingCall(call)
                Call.STATE_ACTIVE -> handleActiveCall(call)
                Call.STATE_DISCONNECTED -> handleDisconnectedCall(call)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        android.util.Log.d("SpamInCallService", "╔════════════════════════════════╗")
        android.util.Log.d("SpamInCallService", "║   🚀 SERVICE CREADO            ║")
        android.util.Log.d("SpamInCallService", "╚════════════════════════════════╝")

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        android.util.Log.d("SpamInCallService", "✅ AudioManager inicializado")
    }

    override fun onCallAdded(call: Call?) {
        super.onCallAdded(call)

        android.util.Log.d("SpamInCallService", "╔════════════════════════════════╗")
        android.util.Log.d("SpamInCallService", "║   📲 LLAMADA DETECTADA         ║")
        android.util.Log.d("SpamInCallService", "╚════════════════════════════════╝")

        if (call == null) {
            android.util.Log.e("SpamInCallService", "❌ ERROR: Call es NULL")
            return
        }

        val phoneNumber = call.details?.handle?.schemeSpecificPart ?: "Desconocido"
        val callState = when (call.state) {
            Call.STATE_NEW -> "NEW"
            Call.STATE_RINGING -> "RINGING"
            Call.STATE_DIALING -> "DIALING"
            Call.STATE_ACTIVE -> "ACTIVE"
            Call.STATE_HOLDING -> "HOLDING"
            Call.STATE_DISCONNECTED -> "DISCONNECTED"
            else -> "UNKNOWN(${call.state})"
        }

        android.util.Log.d("SpamInCallService", "📞 Número: $phoneNumber")
        android.util.Log.d("SpamInCallService", "📋 Estado inicial: $callState")
        android.util.Log.d("SpamInCallService", "🔧 Details: ${call.details}")

        currentCall = call
        call.registerCallback(callCallback)
        hasProcessedCall = false

        android.util.Log.d("SpamInCallService", "✅ Callback registrado correctamente")
    }

    override fun onCallRemoved(call: Call?) {
        super.onCallRemoved(call)

        android.util.Log.d("SpamInCallService", "╔════════════════════════════════╗")
        android.util.Log.d("SpamInCallService", "║   📵 LLAMADA REMOVIDA          ║")
        android.util.Log.d("SpamInCallService", "╚════════════════════════════════╝")

        call?.unregisterCallback(callCallback)

        if (currentCall == call) {
            currentCall = null
            hasProcessedCall = false
        }

        stopRingtone()
        restoreAudioMode()
        handler.removeCallbacksAndMessages(null)
    }

    /**
     * Maneja llamada en estado RINGING
     */
    private fun handleRingingCall(call: Call?) {
        if (call == null) {
            android.util.Log.e("SpamInCallService", "❌ handleRingingCall: Call es NULL")
            return
        }

        val phoneNumber = call.details?.handle?.schemeSpecificPart ?: "Desconocido"

        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
        android.util.Log.d("SpamInCallService", "🔔 RINGING: $phoneNumber")
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")

        // Verificar si es contacto guardado
        if (emergencyDetector.isContact(phoneNumber)) {
            android.util.Log.d("SpamInCallService", "✅ Es contacto guardado → Pasar llamada")
            return
        }

        // Verificar si auto-contestar está activado
        val prefs = getSharedPreferences("SpamStopperPrefs", Context.MODE_PRIVATE)
        val autoAnswer = prefs.getBoolean("auto_answer_enabled", false)

        android.util.Log.d("SpamInCallService", "⚙️ Auto-contestar: $autoAnswer")

        if (!autoAnswer) {
            android.util.Log.d("SpamInCallService", "⚠️ Auto-contestar DESACTIVADO → No interceptar")
            return
        }

        // Auto-contestar en silencio
        android.util.Log.d("SpamInCallService", "🤖 ACTIVANDO auto-contestar...")
        handler.postDelayed({
            answerCallSilently(call)
        }, 500)
    }

    /**
     * Maneja llamada en estado ACTIVE
     */
    private fun handleActiveCall(call: Call?) {
        if (call == null) {
            android.util.Log.e("SpamInCallService", "❌ handleActiveCall: Call es NULL")
            return
        }

        if (hasProcessedCall) {
            android.util.Log.d("SpamInCallService", "⚠️ Llamada ya procesada, saltando")
            return
        }

        hasProcessedCall = true

        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
        android.util.Log.d("SpamInCallService", "✅ Llamada ACTIVE")
        android.util.Log.d("SpamInCallService", "🎤 Iniciando análisis de audio")
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")

        // Iniciar captura y análisis
        startAudioAnalysis(call)
    }

    /**
     * Contesta la llamada en modo silencioso
     */
    private fun answerCallSilently(call: Call?) {
        try {
            android.util.Log.d("SpamInCallService", "═══════════════════════════════")
            android.util.Log.d("SpamInCallService", "🔇 Contestando en SILENCIO...")
            android.util.Log.d("SpamInCallService", "═══════════════════════════════")

            // Configurar audio para captura (sin speaker)
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = false
            audioManager?.isMicrophoneMute = false

            android.util.Log.d("SpamInCallService", "🔊 Audio configurado:")
            android.util.Log.d("SpamInCallService", "   - Modo: MODE_IN_COMMUNICATION")
            android.util.Log.d("SpamInCallService", "   - Speaker: OFF")
            android.util.Log.d("SpamInCallService", "   - Mute: OFF")

            // Contestar
            call?.answer(0)

            android.util.Log.d("SpamInCallService", "✅ Llamada contestada exitosamente")

        } catch (e: Exception) {
            android.util.Log.e("SpamInCallService", "❌ ERROR contestando llamada", e)
            android.util.Log.e("SpamInCallService", "   Mensaje: ${e.message}")
            android.util.Log.e("SpamInCallService", "   Stack: ${e.stackTraceToString()}")
        }
    }

    /**
     * Inicia análisis de audio
     */
    private fun startAudioAnalysis(call: Call) {
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
        android.util.Log.d("SpamInCallService", "🎤 INICIANDO ANÁLISIS DE AUDIO")
        android.util.Log.d("SpamInCallService", "⏱️ Duración máxima: 12 segundos")
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")

        val transcriptBuilder = StringBuilder()
        var beepDetected = false

        // Simulación de captura (12 segundos máx)
        // TODO: Integrar AudioCaptureManager real + Vosk STT

        handler.postDelayed({
            android.util.Log.d("SpamInCallService", "🔄 Iniciando bucle de análisis (6 chunks de 2s)")

            // Simular chunks de audio cada 2 segundos
            for (i in 0 until 6) {
                handler.postDelayed({
                    android.util.Log.d("SpamInCallService", "📦 Chunk $i/6 procesando...")

                    // Simular chunk de audio
                    val mockAudioChunk = ShortArray(1600) // 200ms @ 8kHz

                    // 1. Detectar pitido de robot
                    if (AudioAnalyzer.detectBeep(mockAudioChunk)) {
                        beepDetected = true
                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
                        android.util.Log.d("SpamInCallService", "🤖 ROBOT DETECTADO")
                        android.util.Log.d("SpamInCallService", "🚫 Colgando llamada...")
                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
                        call.disconnect()
                        // TODO: Guardar en historial con label ROBOT
                        return@postDelayed
                    }

                    // 2. Transcribir con STT (simulado)
                    val mockTranscript = when (i) {
                        0 -> "Hola buenos días"
                        1 -> "le llamo de"
                        2 -> "compañía telefónica"
                        3 -> "para ofrecerle"
                        4 -> "una oferta especial"
                        else -> ""
                    }

                    transcriptBuilder.append(mockTranscript).append(" ")

                    android.util.Log.d("SpamInCallService", "📝 Transcripción parcial [$i]: $mockTranscript")

                    // 3. Detectar keywords de emergencia en tiempo real
                    if (emergencyDetector.detectRealTime(transcriptBuilder.toString())) {
                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
                        android.util.Log.d("SpamInCallService", "🚨 EMERGENCIA DETECTADA")
                        android.util.Log.d("SpamInCallService", "🔔 Haciendo sonar tono...")
                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
                        startRinging()
                        // TODO: Mostrar notificación de llamada
                        return@postDelayed
                    }

                    // Último chunk → Clasificar
                    if (i == 5) {
                        val fullTranscript = transcriptBuilder.toString()

                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
                        android.util.Log.d("SpamInCallService", "📋 TRANSCRIPCIÓN COMPLETA:")
                        android.util.Log.d("SpamInCallService", fullTranscript)
                        android.util.Log.d("SpamInCallService", "═══════════════════════════════")

                        // TODO: Clasificar con SpamClassifier
                        // Por ahora, detectar palabras de spam
                        val isSpam = fullTranscript.lowercase().contains("oferta") ||
                                fullTranscript.lowercase().contains("compañía")

                        if (isSpam) {
                            android.util.Log.d("SpamInCallService", "🚫 SPAM DETECTADO")
                            android.util.Log.d("SpamInCallService", "📵 Colgando llamada...")
                            call.disconnect()
                            // TODO: Guardar en historial con label SPAM
                        } else {
                            android.util.Log.d("SpamInCallService", "❓ DUDOSO")
                            android.util.Log.d("SpamInCallService", "📵 Colgando llamada...")
                            call.disconnect()
                            // TODO: Guardar en historial con label DUDOSO
                        }
                    }

                }, (i * 2000).toLong())
            }

        }, 1000)
    }

    /**
     * Hace sonar el tono de llamada (emergencia detectada)
     */
    private fun startRinging() {
        try {
            stopRingtone() // Por si acaso

            val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, ringtoneUri)
            ringtone?.play()

            android.util.Log.d("SpamInCallService", "🔔 Tono de llamada INICIADO")

        } catch (e: Exception) {
            android.util.Log.e("SpamInCallService", "❌ Error reproduciendo tono", e)
        }
    }

    /**
     * Detiene el tono de llamada
     */
    private fun stopRingtone() {
        try {
            ringtone?.stop()
            ringtone = null
        } catch (e: Exception) {
            android.util.Log.e("SpamInCallService", "Error deteniendo tono: ${e.message}")
        }
    }

    /**
     * Maneja llamada desconectada
     */
    private fun handleDisconnectedCall(call: Call?) {
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")
        android.util.Log.d("SpamInCallService", "📵 Llamada DESCONECTADA")
        android.util.Log.d("SpamInCallService", "═══════════════════════════════")

        stopRingtone()
        restoreAudioMode()
        handler.removeCallbacksAndMessages(null)
    }

    /**
     * Restaura modo de audio normal
     */
    private fun restoreAudioMode() {
        try {
            audioManager?.mode = AudioManager.MODE_NORMAL
            audioManager?.isSpeakerphoneOn = false
            android.util.Log.d("SpamInCallService", "🔊 Audio restaurado a MODE_NORMAL")
        } catch (e: Exception) {
            android.util.Log.e("SpamInCallService", "Error restaurando audio: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        android.util.Log.d("SpamInCallService", "╔════════════════════════════════╗")
        android.util.Log.d("SpamInCallService", "║   🛑 SERVICE DESTRUIDO         ║")
        android.util.Log.d("SpamInCallService", "╚════════════════════════════════╝")

        currentCall?.unregisterCallback(callCallback)
        currentCall = null

        stopRingtone()
        restoreAudioMode()
        audioManager = null

        handler.removeCallbacksAndMessages(null)
    }
}