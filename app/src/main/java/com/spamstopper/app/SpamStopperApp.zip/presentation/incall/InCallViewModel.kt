package com.spamstopper.app.presentation.incall

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spamstopper.app.domain.TelecomCallManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Estado de la llamada en curso
 */
data class InCallState(
    val phoneNumber: String = "",
    val contactName: String? = null,
    val duration: Long = 0, // Segundos
    val isSpeakerOn: Boolean = false,
    val isMuted: Boolean = false,
    val isActive: Boolean = true
)

@HiltViewModel
class InCallViewModel @Inject constructor(
    private val telecomCallManager: TelecomCallManager
) : ViewModel() {

    private val _callState = MutableStateFlow(InCallState())
    val callState: StateFlow<InCallState> = _callState.asStateFlow()

    private var timerJob: Job? = null

    /**
     * Inicializa la llamada con los datos del contacto
     */
    fun initCall(phoneNumber: String, contactName: String?) {
        _callState.value = InCallState(
            phoneNumber = phoneNumber,
            contactName = contactName,
            isActive = true
        )

        startTimer()

        android.util.Log.d("InCallViewModel", "Llamada iniciada: $phoneNumber")
    }

    /**
     * Inicia el cronómetro de duración
     */
    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_callState.value.isActive) {
                delay(1000)
                _callState.value = _callState.value.copy(
                    duration = _callState.value.duration + 1
                )
            }
        }
    }

    /**
     * Alterna el altavoz
     */
    fun toggleSpeaker() {
        val newState = !_callState.value.isSpeakerOn
        _callState.value = _callState.value.copy(isSpeakerOn = newState)

        // TODO: Implementar control real del altavoz con AudioManager
        android.util.Log.d("InCallViewModel", "Altavoz: $newState")
    }

    /**
     * Alterna el micrófono (mute)
     */
    fun toggleMute() {
        val newState = !_callState.value.isMuted
        _callState.value = _callState.value.copy(isMuted = newState)

        // TODO: Implementar control real del micrófono con AudioManager
        android.util.Log.d("InCallViewModel", "Mute: $newState")
    }

    /**
     * Finaliza la llamada
     */
    fun endCall() {
        timerJob?.cancel()
        _callState.value = _callState.value.copy(isActive = false)

        telecomCallManager.endCall()

        android.util.Log.d("InCallViewModel", "Llamada finalizada - Duración: ${_callState.value.duration}s")
    }

    /**
     * Formatea la duración en formato MM:SS
     */
    fun getFormattedDuration(): String {
        val duration = _callState.value.duration
        val minutes = duration / 60
        val seconds = duration % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}