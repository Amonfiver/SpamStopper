package com.spamstopper.app.utils

/**
 * ============================================================================
 * Constants.kt - Constantes globales de SpamStopper
 * ============================================================================
 *
 * PROPÓSITO:
 * Define todas las constantes utilizadas a lo largo de la aplicación,
 * incluyendo claves de SharedPreferences, nombres de canales de notificación,
 * tiempos de espera, y otros valores configurables.
 *
 * SECCIONES:
 * - SharedPreferences: Claves para almacenamiento local
 * - Notificaciones: IDs de canales y notificaciones
 * - Análisis: Tiempos y umbrales para el modo secretaria
 * - Base de datos: Nombres de tablas y configuración
 *
 * ACTUALIZADO: Enero 2026 - Añadidas constantes para tono de notificación
 * ============================================================================
 */
object Constants {

    // ═══════════════════════════════════════════════════════════════════════
    // SHARED PREFERENCES
    // ═══════════════════════════════════════════════════════════════════════

    /** Nombre del archivo de SharedPreferences principal */
    const val PREFS_NAME = "spamstopper_prefs"

    /** Modo Secretaria activado/desactivado */
    const val PREF_AUTO_ANSWER_ENABLED = "auto_answer_enabled"

    /** Permitir contactos guardados sin análisis */
    const val PREF_ALLOW_CONTACTS = "allow_contacts"

    /** URI del tono de notificación personalizado */
    const val PREF_NOTIFICATION_RINGTONE = "notification_ringtone_uri"

    /** Nombre del usuario (para detección de legitimidad) */
    const val PREF_USER_NAME = "user_name"

    /** Nombres de familia (separados por coma) */
    const val PREF_FAMILY_NAMES = "family_names"

    /** Palabras clave de emergencia personalizadas */
    const val PREF_EMERGENCY_KEYWORDS = "emergency_keywords"

    /** Duración del análisis en segundos */
    const val PREF_ANALYSIS_DURATION = "analysis_duration"

    /** Sensibilidad de detección de spam (0.0 - 1.0) */
    const val PREF_SPAM_SENSITIVITY = "spam_sensitivity"

    /** Bloquear robots automáticamente */
    const val PREF_AUTO_BLOCK_ROBOTS = "auto_block_robots"

    /** Bloquear spam automáticamente */
    const val PREF_AUTO_BLOCK_SPAM = "auto_block_spam"

    /** Mostrar notificaciones de análisis */
    const val PREF_SHOW_ANALYSIS_NOTIFICATIONS = "show_analysis_notifications"

    /** Primer inicio completado */
    const val PREF_ONBOARDING_COMPLETED = "onboarding_completed"

    /** Vibrar con llamadas legítimas */
    const val PREF_VIBRATION_ENABLED = "vibration_enabled"

    // ═══════════════════════════════════════════════════════════════════════
    // CANALES DE NOTIFICACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    /** Canal para llamadas entrantes */
    const val CHANNEL_INCOMING_CALL = "incoming_call_channel"

    /** Canal para modo secretaria (análisis en progreso) */
    const val CHANNEL_SECRETARY_MODE = "secretary_mode_channel"

    /** Canal para llamadas bloqueadas */
    const val CHANNEL_BLOCKED_CALL = "blocked_call_channel"

    /** Canal para llamadas legítimas detectadas */
    const val CHANNEL_LEGITIMATE_CALL = "legitimate_call_channel"

    // ═══════════════════════════════════════════════════════════════════════
    // IDs DE NOTIFICACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    /** Notificación de llamada entrante activa */
    const val NOTIFICATION_INCOMING_CALL = 2001

    /** Notificación de análisis en progreso */
    const val NOTIFICATION_ANALYZING = 2002

    /** Notificación de llamada bloqueada */
    const val NOTIFICATION_BLOCKED = 2003

    /** Notificación de llamada legítima */
    const val NOTIFICATION_LEGITIMATE = 2004

    // ═══════════════════════════════════════════════════════════════════════
    // TIEMPOS DE ANÁLISIS
    // ═══════════════════════════════════════════════════════════════════════

    /** Duración predeterminada del análisis en milisegundos */
    const val DEFAULT_ANALYSIS_DURATION_MS = 12000L

    /** Duración mínima del análisis */
    const val MIN_ANALYSIS_DURATION_MS = 5000L

    /** Duración máxima del análisis */
    const val MAX_ANALYSIS_DURATION_MS = 20000L

    /** Intervalo entre chunks de audio para análisis */
    const val AUDIO_CHUNK_INTERVAL_MS = 2000L

    /** Delay antes de contestar automáticamente */
    const val AUTO_ANSWER_DELAY_MS = 300L

    // ═══════════════════════════════════════════════════════════════════════
    // UMBRALES DE CLASIFICACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    /** Umbral de confianza para clasificar como spam */
    const val SPAM_CONFIDENCE_THRESHOLD = 0.6f

    /** Umbral de confianza para clasificar como robot */
    const val ROBOT_CONFIDENCE_THRESHOLD = 0.7f

    /** Umbral de confianza para clasificar como legítimo */
    const val LEGITIMATE_CONFIDENCE_THRESHOLD = 0.5f

    /** Umbral para detección de emergencia (prioridad máxima) */
    const val EMERGENCY_CONFIDENCE_THRESHOLD = 0.4f

    // ═══════════════════════════════════════════════════════════════════════
    // BASE DE DATOS
    // ═══════════════════════════════════════════════════════════════════════

    /** Nombre de la base de datos */
    const val DATABASE_NAME = "spamstopper_database"

    /** Versión de la base de datos */
    const val DATABASE_VERSION = 2

    // ═══════════════════════════════════════════════════════════════════════
    // EXTRAS PARA INTENTS
    // ═══════════════════════════════════════════════════════════════════════

    /** Número de teléfono */
    const val EXTRA_PHONE_NUMBER = "phone_number"

    /** Es llamada entrante */
    const val EXTRA_IS_INCOMING = "is_incoming"

    /** Decisión del análisis */
    const val EXTRA_ANALYSIS_DECISION = "analysis_decision"

    /** Categoría del análisis */
    const val EXTRA_ANALYSIS_CATEGORY = "analysis_category"

    /** Razón de legitimidad */
    const val EXTRA_ANALYSIS_REASON = "analysis_reason"

    /** Confianza del análisis */
    const val EXTRA_ANALYSIS_CONFIDENCE = "analysis_confidence"

    /** Palabras clave detectadas */
    const val EXTRA_ANALYSIS_KEYWORDS = "analysis_keywords"

    // ═══════════════════════════════════════════════════════════════════════
    // VALORES PREDETERMINADOS
    // ═══════════════════════════════════════════════════════════════════════

    /** Duración de análisis predeterminada en segundos */
    const val DEFAULT_ANALYSIS_SECONDS = 12

    /** Sensibilidad predeterminada */
    const val DEFAULT_SENSITIVITY = 0.5f

    /** Palabras de emergencia predeterminadas */
    val DEFAULT_EMERGENCY_KEYWORDS = setOf(
        "urgente", "emergencia", "accidente", "hospital",
        "ambulancia", "policía", "ayuda", "grave"
    )
}
