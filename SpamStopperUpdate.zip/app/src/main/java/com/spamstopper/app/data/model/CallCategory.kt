package com.spamstopper.app.data.model

/**
 * ============================================================================
 * CallCategory.kt - Categorías de llamadas con etiquetado detallado
 * ============================================================================
 *
 * PROPÓSITO:
 * Define todas las categorías posibles de llamadas detectadas por SpamStopper.
 * Cada categoría incluye nombre, emoji, descripción corta y explicación detallada
 * que se muestra al usuario cuando consulta "Saber más..." en el historial.
 *
 * CATEGORÍAS:
 * - SPAM_*: Diferentes tipos de llamadas no deseadas
 * - LEGITIMATE_*: Llamadas verificadas como legítimas
 * - UNCERTAIN: No se pudo determinar con certeza
 * - ERROR_*: Errores durante el análisis
 *
 * USO:
 * - BlockedCall entity usa esta categoría para etiquetar llamadas
 * - HistoryScreen muestra el emoji y nombre
 * - CallDetailDialog muestra la explicación completa
 *
 * ACTUALIZADO: Enero 2026 - Añadidas explicaciones detalladas para "Saber más"
 * ============================================================================
 */
enum class CallCategory(
    val emoji: String,
    val displayName: String,
    val shortDescription: String,
    val detailedExplanation: String
) {

    // ═══════════════════════════════════════════════════════════════════════
    // 🤖 ROBOTS Y MARCADORES AUTOMÁTICOS
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_ROBOT(
        emoji = "🤖",
        displayName = "Marcador automático",
        shortDescription = "Robot o sistema automatizado detectado",
        detailedExplanation = """
            Se detectó un sistema de marcación automática (robocall).
            
            📊 Indicadores detectados:
            • Pitido inicial característico de centralitas
            • Silencio prolongado al inicio de la llamada
            • Mensaje pregrabado o voz sintetizada
            • Patrones de audio típicos de IVR
            
            💡 Estos sistemas realizan miles de llamadas automáticas
            buscando personas que respondan para transferirlas a operadores
            o reproducir mensajes publicitarios.
            
            ✅ Acción tomada: Llamada colgada automáticamente.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 📞 TELEMARKETING Y VENTAS
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_TELEMARKETING(
        emoji = "📞",
        displayName = "Telemarketing",
        shortDescription = "Intento de venta de productos o servicios",
        detailedExplanation = """
            Llamada comercial de telemarketing detectada.
            
            📊 Palabras clave detectadas:
            • Frases de venta: "oferta", "promoción", "descuento"
            • Presión de tiempo: "solo hoy", "última oportunidad"
            • Introducciones típicas: "le llamamos de...", "departamento comercial"
            
            💡 Los teleoperadores siguen guiones diseñados para
            mantener tu atención y persuadirte de comprar.
            
            🛡️ SpamStopper detectó patrones típicos de venta agresiva
            y bloqueó la llamada para proteger tu tiempo.
            
            ✅ Acción tomada: Llamada clasificada como spam.
        """.trimIndent()
    ),

    SPAM_INSURANCE(
        emoji = "🛡️",
        displayName = "Venta de seguros",
        shortDescription = "Oferta comercial de pólizas de seguro",
        detailedExplanation = """
            Llamada de venta de seguros detectada.
            
            📊 Palabras clave detectadas:
            • Términos de seguros: "póliza", "cobertura", "prima"
            • Tipos de seguro: "seguro de vida", "seguro médico", "hogar"
            • Tácticas de venta: "protección", "tranquilidad", "sin compromiso"
            
            💡 Las aseguradoras compran bases de datos de teléfonos
            y realizan campañas masivas de captación.
            
            ⚠️ Si realmente necesitas un seguro, es mejor que tú
            contactes directamente a la aseguradora de tu elección.
            
            ✅ Acción tomada: Llamada clasificada como spam comercial.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // ⚡ COMPAÑÍAS DE SERVICIOS
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_ENERGY(
        emoji = "⚡",
        displayName = "Compañía energética",
        shortDescription = "Oferta de luz, gas o servicios energéticos",
        detailedExplanation = """
            Llamada de comercial de energía detectada.
            
            📊 Palabras clave detectadas:
            • Términos energéticos: "luz", "gas", "factura", "consumo"
            • Compañías mencionadas: Endesa, Iberdrola, Naturgy, etc.
            • Ofertas: "ahorro", "tarifa", "potencia contratada"
            
            💡 Las comercializadoras de energía compiten agresivamente
            por captar clientes mediante llamadas masivas.
            
            ⚠️ Importante: Tu compañía actual NUNCA te pedirá datos
            bancarios o personales por teléfono sin que tú lo solicites.
            
            🚨 Si te piden datos de tu factura o cuenta bancaria,
            es muy probable que sea una estafa de suplantación.
            
            ✅ Acción tomada: Llamada clasificada como spam comercial.
        """.trimIndent()
    ),

    SPAM_TELECOM(
        emoji = "📱",
        displayName = "Operadora telefónica",
        shortDescription = "Oferta de fibra, móvil o telecomunicaciones",
        detailedExplanation = """
            Llamada comercial de telecomunicaciones detectada.
            
            📊 Palabras clave detectadas:
            • Servicios: "fibra", "móvil", "internet", "datos", "gigas"
            • Operadoras: Movistar, Vodafone, Orange, MásMóvil, etc.
            • Ofertas: "portabilidad", "tarifa plana", "sin permanencia"
            
            💡 Las operadoras realizan llamadas masivas para captar
            clientes de la competencia con ofertas de portabilidad.
            
            ⚠️ Las ofertas telefónicas suelen tener condiciones
            diferentes a las que te cuentan verbalmente.
            Siempre pide la oferta por escrito antes de aceptar.
            
            ✅ Acción tomada: Llamada clasificada como spam comercial.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 💰 SERVICIOS FINANCIEROS
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_FINANCIAL(
        emoji = "💰",
        displayName = "Servicios financieros",
        shortDescription = "Oferta de préstamos, créditos o inversiones",
        detailedExplanation = """
            Llamada de servicios financieros detectada.
            
            📊 Palabras clave detectadas:
            • Productos: "préstamo", "crédito", "hipoteca", "inversión"
            • Términos: "interés", "cuotas", "financiación", "refinanciar"
            • Tácticas: "dinero rápido", "sin papeleos", "aprobación inmediata"
            
            💡 Muchas de estas llamadas provienen de empresas de
            créditos rápidos con intereses muy altos (TAE > 20%).
            
            🚨 ADVERTENCIA: Nunca proporciones datos bancarios,
            nóminas o documentos de identidad por teléfono.
            
            ⚠️ Los préstamos legítimos se gestionan presencialmente
            o a través de canales oficiales, no por llamadas en frío.
            
            ✅ Acción tomada: Llamada clasificada como spam financiero.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // ⚠️ ESTAFAS Y FRAUDES
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_SCAM(
        emoji = "⚠️",
        displayName = "Posible estafa",
        shortDescription = "Patrones sospechosos de fraude detectados",
        detailedExplanation = """
            ⚠️ ALERTA: Posible intento de estafa detectado.
            
            📊 Indicadores de fraude:
            • Premios falsos: "has ganado", "sorteo", "lotería"
            • Urgencia artificial: "urgente", "actúa ahora"
            • Suplantación: se hacen pasar por entidades oficiales
            • Solicitud de datos sensibles o dinero
            
            🚨 TIPOS COMUNES DE ESTAFA:
            • Falso premio que requiere "pagar tasas"
            • Supuesto familiar en apuros que necesita dinero
            • Suplantación de banco pidiendo claves
            • Falsa herencia de familiar desconocido
            
            ❌ NUNCA proporciones:
            • Números de tarjeta o CVV
            • Claves de banca online
            • Códigos SMS de verificación
            • Transferencias a desconocidos
            
            ✅ Acción tomada: Llamada bloqueada por seguridad.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 📋 ENCUESTAS
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_SURVEYS(
        emoji = "📋",
        displayName = "Encuesta telefónica",
        shortDescription = "Solicitud de participación en encuesta",
        detailedExplanation = """
            Llamada de encuesta detectada.
            
            📊 Palabras clave detectadas:
            • Términos: "encuesta", "opinión", "satisfacción", "valoración"
            • Frases: "solo unos minutos", "breve encuesta", "su opinión"
            
            💡 Tipos de encuestas telefónicas:
            • Encuestas de satisfacción de empresas
            • Estudios de mercado
            • Encuestas políticas o electorales
            • Encuestas que esconden ventas
            
            ⚠️ Muchas "encuestas" son en realidad telemarketing
            disfrazado que termina intentando venderte algo.
            
            ✅ Acción tomada: Llamada clasificada como no deseada.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 🗳️ PROPAGANDA
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_POLITICAL(
        emoji = "🗳️",
        displayName = "Propaganda política",
        shortDescription = "Llamada de campaña o partido político",
        detailedExplanation = """
            Llamada de contenido político detectada.
            
            📊 Palabras clave detectadas:
            • Términos: "partido", "elecciones", "candidato", "votar"
            • Contexto: campaña electoral, afiliación, apoyo político
            
            💡 Los partidos políticos tienen acceso legal al censo
            electoral y pueden realizar llamadas en período de campaña.
            
            ℹ️ Puedes solicitar que te eliminen de sus listas
            de contacto ejerciendo tu derecho RGPD.
            
            ✅ Acción tomada: Llamada clasificada como propaganda.
        """.trimIndent()
    ),

    SPAM_RELIGIOUS(
        emoji = "⛪",
        displayName = "Propaganda religiosa",
        shortDescription = "Llamada de proselitismo religioso",
        detailedExplanation = """
            Llamada de contenido religioso detectada.
            
            📊 Palabras clave detectadas:
            • Términos religiosos: "iglesia", "Dios", "salvación", "biblia"
            • Grupos: Testigos de Jehová, evangelistas, sectas
            • Invitaciones: congregación, estudio bíblico, reunión
            
            💡 Algunos grupos religiosos realizan campañas telefónicas
            de captación de nuevos miembros.
            
            ✅ Acción tomada: Llamada clasificada como no deseada.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 🚫 SPAM GENÉRICO
    // ═══════════════════════════════════════════════════════════════════════

    SPAM_GENERIC(
        emoji = "🚫",
        displayName = "Spam genérico",
        shortDescription = "Llamada no deseada detectada",
        detailedExplanation = """
            Llamada clasificada como spam.
            
            📊 Análisis realizado:
            • Se detectaron múltiples indicadores de spam
            • No se identificó una categoría específica
            • El patrón general coincide con llamadas no deseadas
            
            💡 SpamStopper analiza:
            • El contenido de la conversación
            • Patrones de voz y silencios
            • Palabras clave comerciales
            • Estructura típica de llamadas spam
            
            ✅ Acción tomada: Llamada bloqueada por patrones de spam.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // ✅ LLAMADAS LEGÍTIMAS
    // ═══════════════════════════════════════════════════════════════════════

    LEGITIMATE_CONTACT(
        emoji = "👤",
        displayName = "Contacto guardado",
        shortDescription = "Número en tu lista de contactos",
        detailedExplanation = """
            Llamada de contacto guardado.
            
            ✅ Esta llamada fue permitida porque:
            • El número está en tu lista de contactos
            • No requirió análisis adicional
            
            💡 Los contactos guardados siempre tienen paso libre
            y no son analizados por el modo secretaria.
            
            ℹ️ Puedes desactivar esta función en Configuración
            si prefieres que se analicen todas las llamadas.
        """.trimIndent()
    ),

    LEGITIMATE_MENTIONS_USER(
        emoji = "👤",
        displayName = "Mencionó tu nombre",
        shortDescription = "El llamante dijo tu nombre",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: El llamante mencionó tu nombre
            
            📊 Análisis:
            • Se detectó tu nombre en la conversación
            • Esto indica que la llamada era específicamente para ti
            • No es una llamada masiva de telemarketing
            
            💡 Los telemarketers raramente conocen el nombre
            del destinatario, por eso este indicador es muy fiable.
            
            🔔 Acción tomada: Te alertamos con el tono configurado.
        """.trimIndent()
    ),

    LEGITIMATE_FAMILY(
        emoji = "👨‍👩‍👧",
        displayName = "Mencionó familiar",
        shortDescription = "Mencionó nombre de familia configurado",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Mencionó un nombre de familia
            
            📊 Se detectó uno de los nombres que configuraste
            como familiares importantes.
            
            💡 Esta función te permite no perder llamadas
            sobre personas que te importan (hijos, padres, etc.)
            
            ⚙️ Puedes gestionar los nombres de familia
            en Configuración → Nombres de familia.
            
            🔔 Acción tomada: Te alertamos inmediatamente.
        """.trimIndent()
    ),

    LEGITIMATE_EMERGENCY(
        emoji = "🚨",
        displayName = "Emergencia detectada",
        shortDescription = "Palabras de urgencia o emergencia",
        detailedExplanation = """
            ⚠️ LLAMADA DE EMERGENCIA DETECTADA
            
            ✅ Razón: Palabras clave de emergencia
            
            📊 Se detectaron palabras como:
            • "urgente", "emergencia", "accidente"
            • "hospital", "ambulancia", "policía"
            • Otras palabras de emergencia configuradas
            
            🚨 SpamStopper prioriza SIEMPRE las emergencias.
            Si hay cualquier indicio de urgencia, te alertamos
            inmediatamente sin importar otros indicadores.
            
            🔔 Acción tomada: Alerta prioritaria activada.
        """.trimIndent()
    ),

    LEGITIMATE_WORK(
        emoji = "💼",
        displayName = "Relacionada con trabajo",
        shortDescription = "Contexto laboral detectado",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Contexto de trabajo detectado
            
            📊 Palabras clave detectadas:
            • Términos laborales: "trabajo", "oficina", "reunión"
            • Roles: "jefe", "compañero", "cliente"
            • Proyectos: "proyecto", "entrega", "deadline"
            
            💡 SpamStopper reconoce llamadas profesionales
            para que no pierdas comunicaciones importantes.
            
            🔔 Acción tomada: Te alertamos con el tono configurado.
        """.trimIndent()
    ),

    LEGITIMATE_DELIVERY(
        emoji = "📦",
        displayName = "Entrega o paquete",
        shortDescription = "Servicio de mensajería o reparto",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Servicio de entrega detectado
            
            📊 Indicadores detectados:
            • Términos: "paquete", "entrega", "envío", "pedido"
            • Empresas: Correos, SEUR, MRW, DHL, Amazon, etc.
            • Contexto: reparto, mensajero, dirección
            
            💡 SpamStopper reconoce llamadas de repartidores
            para que no pierdas entregas importantes.
            
            🔔 Acción tomada: Te alertamos con el tono configurado.
        """.trimIndent()
    ),

    LEGITIMATE_MEDICAL(
        emoji = "🏥",
        displayName = "Tema médico",
        shortDescription = "Hospital, médico o centro de salud",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Contexto médico detectado
            
            📊 Indicadores detectados:
            • Entidades: "hospital", "ambulatorio", "centro de salud"
            • Personal: "médico", "doctor", "enfermera"
            • Contexto: "cita", "consulta", "resultados", "analítica"
            
            💡 Las llamadas médicas son prioritarias.
            SpamStopper nunca bloqueará comunicaciones
            relacionadas con tu salud.
            
            🔔 Acción tomada: Te alertamos inmediatamente.
        """.trimIndent()
    ),

    LEGITIMATE_OFFICIAL(
        emoji = "🏛️",
        displayName = "Entidad oficial",
        shortDescription = "Organismo público o administración",
        detailedExplanation = """
            Llamada verificada como posiblemente legítima.
            
            ✅ Razón: Entidad oficial mencionada
            
            📊 Entidades detectadas:
            • Administración: Hacienda, Seguridad Social, Ayuntamiento
            • Justicia: Juzgado, notaría
            • Educación: Colegio, instituto, universidad
            
            ⚠️ IMPORTANTE: Las administraciones públicas
            NUNCA te pedirán datos bancarios o pagos por teléfono.
            Si te piden dinero, es una ESTAFA.
            
            🔔 Acción tomada: Te alertamos para que decidas.
        """.trimIndent()
    ),

    LEGITIMATE_SCHOOL(
        emoji = "🏫",
        displayName = "Colegio o escuela",
        shortDescription = "Centro educativo de tus hijos",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Contexto escolar detectado
            
            📊 Indicadores detectados:
            • Centro: "colegio", "instituto", "guardería"
            • Personal: "profesor", "tutor", "director"
            • Contexto: "niño", "clase", "reunión de padres"
            
            💡 Las llamadas del colegio son prioritarias.
            Pueden ser sobre salud, comportamiento o
            emergencias de tus hijos.
            
            🔔 Acción tomada: Te alertamos inmediatamente.
        """.trimIndent()
    ),

    LEGITIMATE_HUMAN(
        emoji = "💬",
        displayName = "Conversación personal",
        shortDescription = "Llamada humana legítima detectada",
        detailedExplanation = """
            Llamada verificada como legítima.
            
            ✅ Razón: Patrón de conversación humana
            
            📊 Indicadores detectados:
            • Saludos naturales y personalizados
            • Preguntas específicas sobre ti
            • Contexto personal en la conversación
            • Ausencia de patrones de spam
            
            💡 SpamStopper detectó que esta llamada
            tiene características de comunicación genuina,
            no de telemarketing ni robots.
            
            🔔 Acción tomada: Te alertamos con el tono configurado.
        """.trimIndent()
    ),

    // ═══════════════════════════════════════════════════════════════════════
    // 🤔 INCIERTOS Y ERRORES
    // ═══════════════════════════════════════════════════════════════════════

    UNCERTAIN(
        emoji = "❓",
        displayName = "No determinado",
        shortDescription = "No se pudo clasificar con certeza",
        detailedExplanation = """
            Llamada sin clasificación definitiva.
            
            🤔 Razón: Análisis inconcluso
            
            📊 Posibles causas:
            • Audio insuficiente para analizar
            • Indicadores mixtos (spam + legítimo)
            • Llamada muy corta
            • Idioma no reconocido
            
            ⚠️ Por seguridad, cuando no podemos determinar
            si una llamada es spam, preferimos alertarte
            para que tú decidas.
            
            🔔 Acción tomada: Te alertamos por precaución.
        """.trimIndent()
    ),

    ERROR_NO_AUDIO(
        emoji = "🔇",
        displayName = "Sin audio",
        shortDescription = "No se captó audio para analizar",
        detailedExplanation = """
            Error en el análisis: Sin audio.
            
            ❌ No se pudo analizar esta llamada.
            
            📊 Posibles causas:
            • La llamada colgó antes del análisis
            • Problemas con el micrófono
            • Permisos de audio no concedidos
            • El llamante no habló
            
            ⚙️ Verifica que SpamStopper tiene permiso
            de micrófono en Configuración del sistema.
            
            🔔 Acción tomada: Te alertamos por precaución.
        """.trimIndent()
    ),

    ERROR_ANALYSIS_FAILED(
        emoji = "⚙️",
        displayName = "Error de análisis",
        shortDescription = "Fallo durante el procesamiento",
        detailedExplanation = """
            Error técnico durante el análisis.
            
            ❌ El sistema de análisis falló.
            
            📊 Posibles causas:
            • Error en el motor de transcripción
            • Memoria insuficiente
            • Error interno de la aplicación
            
            ⚙️ Si esto ocurre frecuentemente:
            1. Reinicia la aplicación
            2. Verifica que tienes espacio de almacenamiento
            3. Actualiza SpamStopper a la última versión
            
            🔔 Acción tomada: Te alertamos por precaución.
        """.trimIndent()
    );

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODOS AUXILIARES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * ¿Es una categoría de spam?
     */
    fun isSpam(): Boolean = name.startsWith("SPAM_")

    /**
     * ¿Es una categoría legítima?
     */
    fun isLegitimate(): Boolean = name.startsWith("LEGITIMATE_")

    /**
     * ¿Es un error?
     */
    fun isError(): Boolean = name.startsWith("ERROR_")

    /**
     * ¿Es incierto?
     */
    fun isUncertain(): Boolean = this == UNCERTAIN

    /**
     * ¿Se bloqueó la llamada?
     */
    fun wasBlocked(): Boolean = isSpam()

    /**
     * ¿Se alertó al usuario?
     */
    fun wasAlerted(): Boolean = isLegitimate() || isUncertain() || isError()

    /**
     * Obtiene el color para UI (hex)
     */
    fun getColorHex(): String = when {
        isLegitimate() -> "#10B981"  // Verde
        this == SPAM_SCAM -> "#DC2626"  // Rojo intenso
        this == SPAM_ROBOT -> "#7C3AED"  // Púrpura
        isSpam() -> "#EF4444"  // Rojo
        isError() -> "#F59E0B"  // Naranja
        else -> "#6B7280"  // Gris
    }

    /**
     * Obtiene el texto de acción tomada
     */
    fun getActionText(): String = when {
        wasBlocked() -> "🛡️ Llamada bloqueada automáticamente"
        wasAlerted() -> "🔔 Se te alertó de esta llamada"
        else -> "ℹ️ Llamada registrada"
    }

    companion object {
        /**
         * Obtiene todas las categorías de spam
         */
        fun getSpamCategories(): List<CallCategory> =
            entries.filter { it.isSpam() }

        /**
         * Obtiene todas las categorías legítimas
         */
        fun getLegitimateCategories(): List<CallCategory> =
            entries.filter { it.isLegitimate() }

        /**
         * Mapea desde SpamCategory del SecretaryModeManager
         */
        fun fromSpamCategory(spamCategory: String?): CallCategory {
            return when (spamCategory) {
                "ROBOT" -> SPAM_ROBOT
                "TELEMARKETING" -> SPAM_TELEMARKETING
                "SURVEYS" -> SPAM_SURVEYS
                "SCAM" -> SPAM_SCAM
                "RELIGIOUS" -> SPAM_RELIGIOUS
                "POLITICAL" -> SPAM_POLITICAL
                "FINANCIAL" -> SPAM_FINANCIAL
                "INSURANCE" -> SPAM_INSURANCE
                "ENERGY" -> SPAM_ENERGY
                "TELECOM" -> SPAM_TELECOM
                "UNKNOWN_SPAM" -> SPAM_GENERIC
                else -> SPAM_GENERIC
            }
        }

        /**
         * Mapea desde LegitimacyReason del SecretaryModeManager
         */
        fun fromLegitimacyReason(reason: String?): CallCategory {
            return when (reason) {
                "SAID_USER_NAME" -> LEGITIMATE_MENTIONS_USER
                "SAID_FAMILY_NAME" -> LEGITIMATE_FAMILY
                "WORK_RELATED" -> LEGITIMATE_WORK
                "EMERGENCY_KEYWORDS" -> LEGITIMATE_EMERGENCY
                "OFFICIAL_ENTITY" -> LEGITIMATE_OFFICIAL
                "MEDICAL" -> LEGITIMATE_MEDICAL
                "SCHOOL" -> LEGITIMATE_SCHOOL
                "DELIVERY" -> LEGITIMATE_DELIVERY
                "HUMAN_CONVERSATION" -> LEGITIMATE_HUMAN
                else -> LEGITIMATE_HUMAN
            }
        }
    }
}
