package com.spamstopper.app.presentation.setup

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.spamstopper.app.presentation.MainActivity
import dagger.hilt.android.AndroidEntryPoint

/**
 * Activity de configuración inicial
 *
 * Solicita permisos necesarios y configura SpamStopper
 * como app de teléfono predeterminada
 */
@AndroidEntryPoint
class SetupActivity : ComponentActivity() {

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            checkStep()
        } else {
            Toast.makeText(this, "⚠️ Necesitas conceder todos los permisos", Toast.LENGTH_LONG).show()
        }
    }

    private val defaultDialerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkStep()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                SetupScreen(
                    onRequestPermissions = { requestPermissions() },
                    onSetDefaultDialer = { requestDefaultDialer() },
                    onFinish = { finishSetup() }
                )
            }
        }
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.RECORD_AUDIO
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        permissionsLauncher.launch(permissions.toTypedArray())
    }

    private fun requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
            intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            defaultDialerLauncher.launch(intent)
        }
    }

    private fun checkStep() {
        // Recomponer UI para actualizar estados
        setContent {
            MaterialTheme {
                SetupScreen(
                    onRequestPermissions = { requestPermissions() },
                    onSetDefaultDialer = { requestDefaultDialer() },
                    onFinish = { finishSetup() }
                )
            }
        }
    }

    private fun finishSetup() {
        // Guardar que setup está completo
        getSharedPreferences("spamstopper_prefs", MODE_PRIVATE)
            .edit()
            .putBoolean("setup_completed", true)
            .apply()

        // Ir a MainActivity
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun hasAllPermissions(): Boolean {
        val permissions = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.RECORD_AUDIO
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        return permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun isDefaultDialer(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
            return telecomManager.defaultDialerPackage == packageName
        }
        return true
    }

    @Composable
    private fun SetupScreen(
        onRequestPermissions: () -> Unit,
        onSetDefaultDialer: () -> Unit,
        onFinish: () -> Unit
    ) {
        val hasPermissions = hasAllPermissions()
        val isDefaultDialer = isDefaultDialer()
        val setupComplete = hasPermissions && isDefaultDialer

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "🛡️ Configuración Inicial",
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Paso 1: Permisos
                SetupCard(
                    title = "1️⃣ Permisos",
                    description = "Necesitamos acceso a llamadas, contactos y micrófono",
                    isCompleted = hasPermissions,
                    buttonText = if (hasPermissions) "✅ Concedidos" else "Conceder Permisos",
                    onButtonClick = onRequestPermissions,
                    enabled = !hasPermissions
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Paso 2: App predeterminada
                SetupCard(
                    title = "2️⃣ App de Teléfono",
                    description = "Establece SpamStopper como tu app de teléfono predeterminada",
                    isCompleted = isDefaultDialer,
                    buttonText = if (isDefaultDialer) "✅ Configurado" else "Configurar",
                    onButtonClick = onSetDefaultDialer,
                    enabled = hasPermissions && !isDefaultDialer
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Botón finalizar
                Button(
                    onClick = onFinish,
                    enabled = setupComplete,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        text = if (setupComplete) "🚀 ¡Comenzar!" else "Completa los pasos anteriores",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "SpamStopper protegerá tus llamadas automáticamente",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    private fun SetupCard(
        title: String,
        description: String,
        isCompleted: Boolean,
        buttonText: String,
        onButtonClick: () -> Unit,
        enabled: Boolean
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isCompleted)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onButtonClick,
                    enabled = enabled,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(buttonText)
                }
            }
        }
    }
}