package com.spamstopper.app.services.ai

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detector de llamadas robotizadas (IVR)
 *
 * Identifica patrones típicos de menús interactivos,
 * mensajes pregrabados y sistemas automatizados
 */
@Singleton
class RobotCallDetector @Inject constructor() {

    // Patrones de menús IVR en español
    private val ivrPatterns = listOf(
        Regex("\\bpulse\\b.*\\d+", RegexOption.IGNORE_CASE),
        Regex("\\bpresione\\b.*\\d+", RegexOption.IGNORE_CASE),
        Regex("\\bmarque\\b.*\\d+", RegexOption.IGNORE_CASE),
        Regex("\\boprima\\b.*\\d+", RegexOption.IGNORE_CASE),
        Regex("\\bpara\\b.*\\bpulse\\b", RegexOption.IGNORE_CASE),
        Regex("\\bpara\\b.*\\bpresione\\b", RegexOption.IGNORE_CASE),
        Regex("\\bmarcar\\b.*\\bopción\\b", RegexOption.IGNORE_CASE),
        Regex("\\bsi desea\\b.*\\bmarque\\b", RegexOption.IGNORE_CASE),
        Regex("\\bmenú principal\\b", RegexOption.IGNORE_CASE),
        Regex("\\bseleccione una opción\\b", RegexOption.IGNORE_CASE)
    )

    // Frases típicas de mensajes automatizados
    private val automatedPhrases = listOf(
        "este es un mensaje automático",
        "mensaje grabado",
        "sistema automático",
        "llamada automática",
        "no cuelgue",
        "permanezca en línea",
        "su llamada es importante",
        "el siguiente operador disponible",
        "todos nuestros operadores están ocupados",
        "gracias por llamar a"
    )

    // Palabras clave de robots
    private val robotKeywords = setOf(
        "pulse", "presione", "marque", "oprima", "opción",
        "menú", "seleccione", "teclee", "digite"
    )

    /**
     * Detecta si una llamada es de un robot/IVR
     *
     * @param transcript Transcripción del audio de la llamada
     * @return true si se detecta un patrón de robot
     */
    fun isRobotCall(transcript: String): Boolean {
        if (transcript.isEmpty() || transcript.length < 10) {
            return false
        }

        val lowerTranscript = transcript.lowercase()

        // 1. Detectar patrones IVR
        if (ivrPatterns.any { it.containsMatchIn(lowerTranscript) }) {
            android.util.Log.d("RobotDetector", "🤖 Patrón IVR detectado")
            return true
        }

        // 2. Detectar frases automatizadas
        val automatedMatch = automatedPhrases.count {
            lowerTranscript.contains(it)
        }
        if (automatedMatch >= 1) {
            android.util.Log.d("RobotDetector", "🤖 Mensaje automático detectado ($automatedMatch coincidencias)")
            return true
        }

        // 3. Detectar alta densidad de palabras clave de robot
        val words = lowerTranscript.split("\\s+".toRegex())
        val robotKeywordCount = words.count { it in robotKeywords }
        val robotKeywordRatio = if (words.isNotEmpty()) {
            robotKeywordCount.toFloat() / words.size
        } else 0f

        if (robotKeywordRatio > 0.15f) { // 15% o más de palabras son de robot
            android.util.Log.d("RobotDetector", "🤖 Alta densidad de palabras robot (${robotKeywordRatio * 100}%)")
            return true
        }

        // 4. Detectar ritmo robótico (repetición excesiva)
        val uniqueWords = words.toSet()
        val repetitionRatio = if (words.size > 20) {
            uniqueWords.size.toFloat() / words.size
        } else 1f

        if (repetitionRatio < 0.5f && words.size > 20) {
            android.util.Log.d("RobotDetector", "🤖 Patrón de repetición robótica (ratio: $repetitionRatio)")
            return true
        }

        return false
    }

    /**
     * Calcula un score de confianza de que es robot (0.0 - 1.0)
     */
    fun getRobotConfidence(transcript: String): Float {
        if (transcript.isEmpty()) return 0f

        val lowerTranscript = transcript.lowercase()
        var score = 0f

        // Patrones IVR (+0.5)
        if (ivrPatterns.any { it.containsMatchIn(lowerTranscript) }) {
            score += 0.5f
        }

        // Frases automatizadas (+0.3 por cada una, máx +0.6)
        val automatedCount = automatedPhrases.count { lowerTranscript.contains(it) }
        score += (automatedCount * 0.3f).coerceAtMost(0.6f)

        // Palabras clave robot (+0.2)
        val words = lowerTranscript.split("\\s+".toRegex())
        val robotKeywordCount = words.count { it in robotKeywords }
        if (robotKeywordCount >= 3) {
            score += 0.2f
        }

        // Repetición (+0.2)
        if (words.size > 20) {
            val uniqueWords = words.toSet()
            val repetitionRatio = uniqueWords.size.toFloat() / words.size
            if (repetitionRatio < 0.6f) {
                score += 0.2f
            }
        }

        return score.coerceIn(0f, 1f)
    }

    /**
     * Obtiene los patrones detectados en la transcripción
     */
    fun getDetectedPatterns(transcript: String): List<String> {
        val patterns = mutableListOf<String>()
        val lowerTranscript = transcript.lowercase()

        ivrPatterns.forEach { regex ->
            regex.find(lowerTranscript)?.let {
                patterns.add("Patrón IVR: ${it.value}")
            }
        }

        automatedPhrases.forEach { phrase ->
            if (lowerTranscript.contains(phrase)) {
                patterns.add("Frase automatizada: $phrase")
            }
        }

        return patterns
    }
}