package com.spamstopper.app.domain

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.graphics.drawable.Icon
import com.spamstopper.app.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * TelecomCallManager - Gestión avanzada de llamadas con PhoneAccount
 *
 * Responsabilidades:
 * - Registrar PhoneAccount SELF_MANAGED
 * - Iniciar llamadas salientes usando nuestro sistema
 * - Gestionar estado de llamadas activas
 */
@Singleton
class TelecomCallManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val telecomManager: TelecomManager =
        context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

    companion object {
        const val PHONE_ACCOUNT_ID = "SpamStopperAccount"
        const val PHONE_ACCOUNT_LABEL = "SpamStopper"
    }

    /**
     * Registra el PhoneAccount de la app
     * Debe llamarse en Application.onCreate()
     */
    fun registerPhoneAccount() {
        try {
            val componentName = ComponentName(
                context,
                com.spamstopper.app.service.SpamStopperConnectionService::class.java
            )

            val phoneAccountHandle = PhoneAccountHandle(
                componentName,
                PHONE_ACCOUNT_ID
            )

            // Verificar si ya está registrado
            val existingAccount = telecomManager.getPhoneAccount(phoneAccountHandle)
            if (existingAccount != null) {
                android.util.Log.d("TelecomCallManager", "PhoneAccount ya registrado")
                return
            }

            // Crear PhoneAccount con capacidad SELF_MANAGED
            val phoneAccount = PhoneAccount.builder(
                phoneAccountHandle,
                PHONE_ACCOUNT_LABEL
            )
                .setCapabilities(
                    PhoneAccount.CAPABILITY_SELF_MANAGED or
                            PhoneAccount.CAPABILITY_CALL_PROVIDER
                )
                .setIcon(Icon.createWithResource(context, R.mipmap.ic_launcher))
                .setHighlightColor(0xFF6200EE.toInt())
                .setShortDescription("SpamStopper Call System")
                .build()

            telecomManager.registerPhoneAccount(phoneAccount)

            android.util.Log.d("TelecomCallManager", "✅ PhoneAccount registrado exitosamente")

        } catch (e: Exception) {
            android.util.Log.e("TelecomCallManager", "❌ Error registrando PhoneAccount", e)
        }
    }

    /**
     * Inicia una llamada saliente usando nuestro PhoneAccount
     */
    fun placeCall(phoneNumber: String): Boolean {
        return try {
            val componentName = ComponentName(
                context,
                com.spamstopper.app.service.SpamStopperConnectionService::class.java
            )

            val phoneAccountHandle = PhoneAccountHandle(
                componentName,
                PHONE_ACCOUNT_ID
            )

            val uri = Uri.fromParts("tel", phoneNumber, null)

            val extras = Bundle().apply {
                putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, phoneAccountHandle)
                putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
                putInt(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, VideoProfile.STATE_AUDIO_ONLY)
            }

            telecomManager.placeCall(uri, extras)

            android.util.Log.d("TelecomCallManager", "✅ Llamada iniciada: $phoneNumber")
            true

        } catch (e: SecurityException) {
            android.util.Log.e("TelecomCallManager", "❌ Sin permiso CALL_PHONE", e)
            false
        } catch (e: Exception) {
            android.util.Log.e("TelecomCallManager", "❌ Error iniciando llamada", e)
            false
        }
    }

    /**
     * Finaliza la llamada actual
     */
    fun endCall(): Boolean {
        return try {
            if (telecomManager.isInCall) {
                telecomManager.endCall()
                android.util.Log.d("TelecomCallManager", "✅ Llamada finalizada")
                true
            } else {
                android.util.Log.w("TelecomCallManager", "⚠️ No hay llamada activa")
                false
            }
        } catch (e: Exception) {
            android.util.Log.e("TelecomCallManager", "❌ Error finalizando llamada", e)
            false
        }
    }

    /**
     * Verifica si hay una llamada en curso
     */
    fun isInCall(): Boolean {
        return try {
            telecomManager.isInCall
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Obtiene el PhoneAccountHandle de la app
     */
    fun getPhoneAccountHandle(): PhoneAccountHandle {
        val componentName = ComponentName(
            context,
            com.spamstopper.app.service.SpamStopperConnectionService::class.java
        )

        return PhoneAccountHandle(componentName, PHONE_ACCOUNT_ID)
    }
}