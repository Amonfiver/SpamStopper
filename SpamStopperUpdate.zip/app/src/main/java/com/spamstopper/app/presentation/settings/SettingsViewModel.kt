package com.spamstopper.app.presentation.settings

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import android.provider.CallLog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spamstopper.app.data.database.BlockedCallDao
import com.spamstopper.app.data.preferences.UserPreferences
import com.spamstopper.app.domain.EmergencyKeywordDetector
import com.spamstopper.app.utils.Constants
import com.spamstopper.app.utils.PermissionsHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * ============================================================================
 * SettingsViewModel.kt - ViewModel para configuración de SpamStopper
 * ============================================================================
 *
 * PROPÓSITO:
 * Gestiona el estado y la lógica de negocio para la pantalla de configuración.
 * Maneja todas las preferencias del usuario incluyendo:
 * - Modo Secretaria (auto-answer)
 * - Tono de notificación personalizado
 * - Palabras clave de emergencia
 * - Nombres de familia
 * - Permisos del sistema
 *
 * PERSISTENCIA:
 * - SharedPreferences para configuración básica (Constants.PREFS_NAME)
 * - DataStore para preferencias complejas (UserPreferences)
 *
 * ACTUALIZADO: Enero 2026 - Añadido soporte para tono de notificación
 * ============================================================================
 */

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val emergencyDetector: EmergencyKeywordDetector,
    private val userPreferences: UserPreferences,
    private val blockedCallDao: BlockedCallDao
) : ViewModel() {

    companion object {
        private const val TAG = "SettingsViewModel"
        private const val PREF_NOTIFICATION_RINGTONE = "notification_ringtone_uri"
        private const val PREF_FAMILY_NAMES = "family_names"
        private const val PREF_USER_NAME = "user_name"
    }

    private val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    init {
        loadSettings()
        checkPermissions()
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CARGA DE CONFIGURACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    private fun loadSettings() {
        viewModelScope.launch {
            val autoAnswer = prefs.getBoolean(Constants.PREF_AUTO_ANSWER_ENABLED, false)
            val allowContacts = prefs.getBoolean(Constants.PREF_ALLOW_CONTACTS, true)
            val keywords = emergencyDetector.getUserKeywords().joinToString(", ")
            val familyNames = prefs.getString(PREF_FAMILY_NAMES, "") ?: ""
            val userName = prefs.getString(PREF_USER_NAME, "") ?: ""

            // Cargar tono de notificación
            val ringtoneUriString = prefs.getString(PREF_NOTIFICATION_RINGTONE, null)
            val ringtoneUri = ringtoneUriString?.let { Uri.parse(it) }
            val ringtoneName = getRingtoneName(ringtoneUri)

            _state.value = _state.value.copy(
                autoAnswerEnabled = autoAnswer,
                allowContactsEnabled = allowContacts,
                customKeywords = keywords,
                familyNames = familyNames,
                userName = userName,
                notificationRingtoneUri = ringtoneUri,
                notificationRingtoneName = ringtoneName
            )

            android.util.Log.d(TAG, "═══════════════════════════════════════")
            android.util.Log.d(TAG, "⚙️ CONFIGURACIÓN CARGADA")
            android.util.Log.d(TAG, "   Auto-answer: $autoAnswer")
            android.util.Log.d(TAG, "   Allow contacts: $allowContacts")
            android.util.Log.d(TAG, "   Ringtone: $ringtoneName")
            android.util.Log.d(TAG, "   User name: $userName")
            android.util.Log.d(TAG, "═══════════════════════════════════════")
        }
    }

    private fun getRingtoneName(uri: Uri?): String {
        if (uri == null) return "Tono predeterminado"

        return try {
            val ringtone = RingtoneManager.getRingtone(context, uri)
            ringtone?.getTitle(context) ?: "Tono personalizado"
        } catch (e: Exception) {
            "Tono personalizado"
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PERMISOS
    // ═══════════════════════════════════════════════════════════════════════

    fun checkPermissions() {
        val hasAll = PermissionsHelper.hasAllPermissions(context)
        val hasSecretary = PermissionsHelper.hasSecretaryPermissions(context)
        val missing = PermissionsHelper.getMissingSecretaryPermissions(context)

        _state.value = _state.value.copy(
            hasAllPermissions = hasAll,
            hasSecretaryPermissions = hasSecretary,
            missingPermissions = missing
        )

        android.util.Log.d(TAG, "🔐 Permisos: All=$hasAll, Secretary=$hasSecretary")
    }

    fun requestPermissions() {
        _state.value = _state.value.copy(needsPermissionRequest = true)
    }

    fun clearPermissionRequest() {
        _state.value = _state.value.copy(needsPermissionRequest = false)
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MODO SECRETARIA
    // ═══════════════════════════════════════════════════════════════════════

    fun setAutoAnswer(enabled: Boolean) {
        if (enabled && !_state.value.hasSecretaryPermissions) {
            _state.value = _state.value.copy(needsPermissionRequest = true)
            showMessage("⚠️ Se requieren permisos adicionales")
            return
        }

        prefs.edit().putBoolean(Constants.PREF_AUTO_ANSWER_ENABLED, enabled).apply()
        _state.value = _state.value.copy(autoAnswerEnabled = enabled)

        android.util.Log.d(TAG, "🎙️ MODO SECRETARIA: ${if (enabled) "ACTIVADO ✅" else "DESACTIVADO ❌"}")
        showMessage(if (enabled) "✅ Modo Secretaria activado" else "⚠️ Modo Secretaria desactivado")
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TONO DE NOTIFICACIÓN
    // ═══════════════════════════════════════════════════════════════════════

    fun setNotificationRingtone(uri: Uri?) {
        val uriString = uri?.toString()
        prefs.edit().putString(PREF_NOTIFICATION_RINGTONE, uriString).apply()

        val name = getRingtoneName(uri)
        _state.value = _state.value.copy(
            notificationRingtoneUri = uri,
            notificationRingtoneName = name
        )

        android.util.Log.d(TAG, "🔔 Tono cambiado: $name")
        showMessage("✅ Tono de notificación actualizado")
    }

    fun testNotificationRingtone() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val uri = _state.value.notificationRingtoneUri
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

                val ringtone = RingtoneManager.getRingtone(context, uri)
                ringtone?.play()

                // Detener después de 3 segundos
                kotlinx.coroutines.delay(3000)
                ringtone?.stop()

                android.util.Log.d(TAG, "🔔 Probando tono...")
            } catch (e: Exception) {
                android.util.Log.e(TAG, "❌ Error reproduciendo tono: ${e.message}")
                withContext(Dispatchers.Main) {
                    showMessage("❌ Error al reproducir el tono")
                }
            }
        }
    }

    /**
     * Obtiene el URI del tono configurado (para usar en SpamInCallService)
     */
    fun getNotificationRingtoneUri(): Uri {
        return _state.value.notificationRingtoneUri
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CONTACTOS
    // ═══════════════════════════════════════════════════════════════════════

    fun setAllowContacts(enabled: Boolean) {
        prefs.edit().putBoolean(Constants.PREF_ALLOW_CONTACTS, enabled).apply()
        _state.value = _state.value.copy(allowContactsEnabled = enabled)
        android.util.Log.d(TAG, "📇 Permitir contactos: $enabled")
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PALABRAS CLAVE Y NOMBRES
    // ═══════════════════════════════════════════════════════════════════════

    fun setCustomKeywords(keywords: String) {
        val keywordsList = keywords
            .split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }

        emergencyDetector.saveUserKeywords(keywordsList)
        _state.value = _state.value.copy(customKeywords = keywords)

        android.util.Log.d(TAG, "🚨 Keywords guardadas: ${keywordsList.size}")
        showMessage("✅ Palabras clave guardadas")
    }

    fun setFamilyNames(names: String) {
        prefs.edit().putString(PREF_FAMILY_NAMES, names).apply()
        _state.value = _state.value.copy(familyNames = names)

        // También guardar en UserPreferences para SecretaryModeManager
        viewModelScope.launch {
            val namesSet = names
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()
            userPreferences.setFamilyNames(namesSet)
        }

        android.util.Log.d(TAG, "👨‍👩‍👧 Nombres de familia guardados")
        showMessage("✅ Nombres de familia guardados")
    }

    fun setUserName(name: String) {
        prefs.edit().putString(PREF_USER_NAME, name).apply()
        _state.value = _state.value.copy(userName = name)

        viewModelScope.launch {
            userPreferences.setUserName(name)
        }

        android.util.Log.d(TAG, "👤 Nombre de usuario: $name")
        showMessage("✅ Nombre guardado")
    }

    // ═══════════════════════════════════════════════════════════════════════
    // HISTORIAL
    // ═══════════════════════════════════════════════════════════════════════

    fun clearCallHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Limpiar historial de SpamStopper
                blockedCallDao.deleteAll()

                // Intentar limpiar call log del sistema
                try {
                    context.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null)
                } catch (e: SecurityException) {
                    android.util.Log.w(TAG, "Sin permiso WRITE_CALL_LOG")
                }

                android.util.Log.d(TAG, "🗑️ Historial eliminado")
                withContext(Dispatchers.Main) {
                    showMessage("✅ Historial eliminado")
                }
            } catch (e: Exception) {
                android.util.Log.e(TAG, "❌ Error eliminando historial: ${e.message}")
                withContext(Dispatchers.Main) {
                    showMessage("❌ Error al eliminar historial")
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MENSAJES
    // ═══════════════════════════════════════════════════════════════════════

    private fun showMessage(message: String) {
        _state.value = _state.value.copy(snackbarMessage = message)
    }

    fun clearMessage() {
        _state.value = _state.value.copy(snackbarMessage = null)
    }
}

/**
 * Estado de la pantalla de configuración
 */
data class SettingsState(
    // Configuración básica
    val autoAnswerEnabled: Boolean = false,
    val allowContactsEnabled: Boolean = true,
    val customKeywords: String = "",
    val familyNames: String = "",
    val userName: String = "",

    // Tono de notificación
    val notificationRingtoneUri: Uri? = null,
    val notificationRingtoneName: String = "Tono predeterminado",

    // Permisos
    val hasAllPermissions: Boolean = false,
    val hasSecretaryPermissions: Boolean = false,
    val missingPermissions: List<String> = emptyList(),
    val needsPermissionRequest: Boolean = false,

    // UI
    val snackbarMessage: String? = null
)
