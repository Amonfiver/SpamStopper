package com.spamstopper.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.spamstopper.app.data.model.CallCategory

/**
 * ============================================================================
 * BlockedCall.kt - Entity para historial de llamadas analizadas
 * ============================================================================
 *
 * PROPÓSITO:
 * Almacena información de cada llamada procesada por SpamStopper, incluyendo
 * tanto llamadas bloqueadas (spam) como llamadas permitidas (legítimas).
 *
 * INFORMACIÓN ALMACENADA:
 * - Datos básicos: número, timestamp, duración
 * - Clasificación: categoría, confianza del análisis
 * - Detalles: palabras clave detectadas, transcripción parcial
 * - Metadata: si fue bloqueada, si el usuario la marcó manualmente
 *
 * PRIVACIDAD:
 * - NO almacena audio completo
 * - La transcripción se limita a fragmentos relevantes
 * - El número se puede mostrar ofuscado en UI
 *
 * USO:
 * - HistoryScreen muestra la lista de llamadas
 * - CallDetailDialog muestra el detalle con "Saber más..."
 * - Estadísticas y reportes de spam bloqueado
 *
 * ACTUALIZADO: Enero 2026 - Añadidos campos para "Saber más"
 * ============================================================================
 */
@Entity(tableName = "blocked_calls")
data class BlockedCall(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /**
     * Número de teléfono del llamante
     */
    val phoneNumber: String,

    /**
     * Nombre del contacto si existe, null si es desconocido
     */
    val contactName: String? = null,

    /**
     * Categoría de la llamada (spam, legítima, etc.)
     */
    val category: CallCategory,

    /**
     * Timestamp Unix en milisegundos
     */
    val timestamp: Long,

    /**
     * Duración del análisis en segundos
     */
    val analysisSeconds: Int,

    /**
     * Confianza del análisis (0.0 - 1.0)
     */
    val confidence: Float = 0f,

    /**
     * Si la llamada fue bloqueada automáticamente
     */
    val wasBlocked: Boolean = false,

    /**
     * Si el usuario alertó de esta llamada
     */
    val wasAlerted: Boolean = false,

    /**
     * Palabras clave detectadas durante el análisis (JSON array como string)
     * Ejemplo: "oferta,promoción,seguro"
     */
    val detectedKeywords: String = "",

    /**
     * Transcripción parcial (primeros 200 caracteres relevantes)
     * Se almacena para referencia pero NO se muestra completo por privacidad
     */
    val partialTranscript: String = "",

    /**
     * Si el usuario marcó/corrigió esta clasificación manualmente
     */
    val markedByUser: Boolean = false,

    /**
     * Categoría corregida por el usuario (si aplica)
     */
    val userCorrectedCategory: CallCategory? = null,

    /**
     * Notas del usuario sobre esta llamada
     */
    val userNotes: String? = null
) {
    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODOS DE FORMATEO PARA UI
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Obtiene el número ofuscado para mostrar en UI
     * Ejemplo: +34 612 345 678 → +34 612 *** 678
     */
    fun getObfuscatedNumber(): String {
        return if (phoneNumber.length > 7) {
            val prefix = phoneNumber.take(phoneNumber.length - 6)
            val suffix = phoneNumber.takeLast(3)
            "$prefix***$suffix"
        } else {
            "***${phoneNumber.takeLast(3)}"
        }
    }

    /**
     * Obtiene el nombre a mostrar (contacto o número)
     */
    fun getDisplayName(): String {
        return contactName ?: phoneNumber
    }

    /**
     * Formatea el timestamp a fecha legible
     */
    fun getFormattedDate(): String {
        val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timestamp))
    }

    /**
     * Obtiene tiempo relativo (ej: "Hace 2 horas")
     */
    fun getRelativeTime(): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp

        return when {
            diff < 60_000 -> "Hace un momento"
            diff < 3600_000 -> {
                val mins = diff / 60_000
                "Hace $mins ${if (mins == 1L) "minuto" else "minutos"}"
            }
            diff < 86400_000 -> {
                val hours = diff / 3600_000
                "Hace $hours ${if (hours == 1L) "hora" else "horas"}"
            }
            diff < 604800_000 -> {
                val days = diff / 86400_000
                "Hace $days ${if (days == 1L) "día" else "días"}"
            }
            else -> getFormattedDate()
        }
    }

    /**
     * Obtiene la lista de palabras clave como List<String>
     */
    fun getKeywordsList(): List<String> {
        return if (detectedKeywords.isBlank()) {
            emptyList()
        } else {
            detectedKeywords.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
    }

    /**
     * Obtiene el porcentaje de confianza formateado
     */
    fun getConfidencePercent(): String {
        return "${(confidence * 100).toInt()}%"
    }

    /**
     * Obtiene el emoji de la categoría
     */
    fun getCategoryEmoji(): String {
        return (userCorrectedCategory ?: category).emoji
    }

    /**
     * Obtiene el nombre de la categoría
     */
    fun getCategoryDisplayName(): String {
        return (userCorrectedCategory ?: category).displayName
    }

    /**
     * Obtiene la descripción corta
     */
    fun getCategoryShortDescription(): String {
        return (userCorrectedCategory ?: category).shortDescription
    }

    /**
     * Obtiene la explicación detallada para "Saber más"
     */
    fun getDetailedExplanation(): String {
        return (userCorrectedCategory ?: category).detailedExplanation
    }

    /**
     * Obtiene el texto de acción tomada
     */
    fun getActionTakenText(): String {
        return when {
            wasBlocked -> "🛡️ Bloqueada automáticamente"
            wasAlerted -> "🔔 Te alertamos de esta llamada"
            else -> "ℹ️ Registrada"
        }
    }

    /**
     * Obtiene el color de la categoría
     */
    fun getCategoryColor(): String {
        return (userCorrectedCategory ?: category).getColorHex()
    }

    /**
     * ¿La categoría efectiva es spam?
     */
    fun isEffectivelySpam(): Boolean {
        return (userCorrectedCategory ?: category).isSpam()
    }

    /**
     * ¿La categoría efectiva es legítima?
     */
    fun isEffectivelyLegitimate(): Boolean {
        return (userCorrectedCategory ?: category).isLegitimate()
    }

    /**
     * ¿El usuario corrigió la clasificación?
     */
    fun wasUserCorrected(): Boolean {
        return markedByUser && userCorrectedCategory != null
    }

    /**
     * Genera resumen para notificaciones
     */
    fun getNotificationSummary(): String {
        val emoji = getCategoryEmoji()
        val name = contactName ?: getObfuscatedNumber()
        val action = if (wasBlocked) "bloqueada" else "detectada"
        return "$emoji $name - ${getCategoryDisplayName()} ($action)"
    }

    companion object {
        /**
         * Crea un BlockedCall desde el resultado del análisis
         */
        fun fromAnalysisResult(
            phoneNumber: String,
            contactName: String?,
            category: CallCategory,
            confidence: Float,
            wasBlocked: Boolean,
            keywords: List<String>,
            transcript: String,
            analysisTimeMs: Long
        ): BlockedCall {
            return BlockedCall(
                phoneNumber = phoneNumber,
                contactName = contactName,
                category = category,
                timestamp = System.currentTimeMillis(),
                analysisSeconds = (analysisTimeMs / 1000).toInt(),
                confidence = confidence,
                wasBlocked = wasBlocked,
                wasAlerted = !wasBlocked,
                detectedKeywords = keywords.take(10).joinToString(","),
                partialTranscript = transcript.take(200)
            )
        }
    }
}
