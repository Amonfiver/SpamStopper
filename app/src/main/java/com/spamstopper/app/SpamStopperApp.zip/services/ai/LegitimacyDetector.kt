package com.spamstopper.app.services.ai

import android.util.Log
import com.spamstopper.app.data.model.CallCategory
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detector de llamadas legítimas
 *
 * Identifica llamadas que el usuario debería recibir:
 * - Menciona su nombre
 * - Menciona familia
 * - Palabras de emergencia
 * - Palabras clave personalizadas
 */
@Singleton
class LegitimacyDetector @Inject constructor() {

    companion object {
        private const val TAG = "LegitimacyDetector"

        // Palabras de emergencia por defecto
        private val DEFAULT_EMERGENCY_KEYWORDS = setOf(
            "urgente", "emergencia", "accidente", "hospital",
            "policía", "fuego", "ayuda", "socorro"
        )

        // Patrones de presentación personal
        private val PERSONAL_PATTERNS = setOf(
            "soy", "me llamo", "habla", "busco a", "está",
            "hablar con", "comunicarme con", "necesito hablar"
        )
    }

    /**
     * Detecta si una llamada es legítima
     *
     * @param transcription Texto transcrito
     * @param userName Nombre del usuario
     * @param familyNames Nombres de familia
     * @param customKeywords Palabras clave personalizadas
     * @return Categoría legítima o null si no es legítima
     */
    fun detect(
        transcription: String,
        userName: String,
        familyNames: Set<String>,
        customKeywords: Set<String> = emptySet()
    ): CallCategory? {
        if (transcription.isBlank()) {
            return null
        }

        val text = transcription.lowercase().trim()
        Log.d(TAG, "🔍 Analizando legitimidad: $text")

        // 1. Verificar emergencia (prioridad máxima)
        if (containsEmergency(text, customKeywords)) {
            Log.d(TAG, "✅ EMERGENCIA detectada")
            return CallCategory.LEGITIMATE_EMERGENCY
        }

        // 2. Verificar nombre del usuario
        if (userName.isNotBlank() && text.contains(userName.lowercase())) {
            Log.d(TAG, "✅ Menciona nombre de usuario")
            return CallCategory.LEGITIMATE_MENTIONS_USER
        }

        // 3. Verificar nombres de familia
        if (familyNames.any { text.contains(it.lowercase()) }) {
            Log.d(TAG, "✅ Menciona nombre de familia")
            return CallCategory.LEGITIMATE_FAMILY
        }

        // 4. Verificar palabras clave personalizadas
        if (customKeywords.any { text.contains(it.lowercase()) }) {
            Log.d(TAG, "✅ Palabra clave personalizada detectada")
            return CallCategory.LEGITIMATE_KEYWORD
        }

        // 5. Verificar patrones de presentación personal
        if (containsPersonalPattern(text)) {
            Log.d(TAG, "✅ Intención personal detectada")
            return CallCategory.LEGITIMATE_PERSONAL
        }

        // No es legítima
        Log.d(TAG, "❌ No detectada como legítima")
        return null
    }

    /**
     * Verifica palabras de emergencia
     */
    private fun containsEmergency(text: String, customKeywords: Set<String>): Boolean {
        val allEmergencyKeywords = DEFAULT_EMERGENCY_KEYWORDS + customKeywords
        return allEmergencyKeywords.any {
            text.contains(it, ignoreCase = true)
        }
    }

    /**
     * Verifica patrones de presentación personal
     */
    private fun containsPersonalPattern(text: String): Boolean {
        return PERSONAL_PATTERNS.any {
            text.contains(it, ignoreCase = true)
        }
    }

    /**
     * Obtiene razón de detección (para mostrar al usuario)
     */
    fun getDetectionReason(
        transcription: String,
        userName: String,
        familyNames: Set<String>,
        customKeywords: Set<String> = emptySet()
    ): String {
        val text = transcription.lowercase()

        return when {
            containsEmergency(text, customKeywords) ->
                "Detectado: Emergencia"

            userName.isNotBlank() && text.contains(userName.lowercase()) ->
                "Detectado: Menciona tu nombre"

            familyNames.any { text.contains(it.lowercase()) } -> {
                val matchedName = familyNames.first { text.contains(it.lowercase()) }
                "Detectado: Menciona a $matchedName"
            }

            customKeywords.any { text.contains(it.lowercase()) } -> {
                val matchedKeyword = customKeywords.first { text.contains(it.lowercase()) }
                "Detectado: Palabra clave '$matchedKeyword'"
            }

            containsPersonalPattern(text) ->
                "Detectado: Intención personal"

            else -> "Motivo desconocido"
        }
    }
}