package com.spamstopper.app.presentation.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.toColorInt
import com.spamstopper.app.data.database.entities.BlockedCall
import com.spamstopper.app.data.model.CallCategory
import java.text.SimpleDateFormat
import java.util.*

/**
 * ============================================================================
 * HistoryScreen.kt - Pantalla de historial de llamadas analizadas
 * ============================================================================
 *
 * PROPÓSITO:
 * Muestra el historial de todas las llamadas procesadas por SpamStopper,
 * incluyendo tanto spam bloqueado como llamadas legítimas permitidas.
 *
 * FUNCIONALIDADES:
 * - Lista de llamadas con filtros (todas, spam, legítimas)
 * - Tarjetas con emoji, nombre/número, categoría y tiempo
 * - Botón "Saber más..." que abre diálogo con explicación detallada
 * - Posibilidad de llamar de vuelta
 * - Opción de marcar/corregir clasificación
 *
 * COMPONENTES:
 * - HistoryScreen: Pantalla principal con filtros y lista
 * - CallHistoryCard: Tarjeta individual de llamada
 * - CallDetailDialog: Diálogo "Saber más..." con explicación completa
 *
 * ACTUALIZADO: Enero 2026 - Añadido botón "Saber más" con explicaciones
 * ============================================================================
 */

/**
 * Filtros disponibles para el historial
 */
enum class HistoryFilter(val displayName: String, val emoji: String) {
    ALL("Todas", "📋"),
    BLOCKED("Bloqueadas", "🛡️"),
    ALLOWED("Permitidas", "✅"),
    SPAM("Spam", "🚫"),
    LEGITIMATE("Legítimas", "👤")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    blockedCalls: List<BlockedCall>,
    onCallClick: (BlockedCall) -> Unit,
    onCallBack: (BlockedCall) -> Unit,
    onMarkAsSpam: (BlockedCall) -> Unit,
    onMarkAsLegitimate: (BlockedCall) -> Unit
) {
    var selectedFilter by remember { mutableStateOf(HistoryFilter.ALL) }
    var selectedCall by remember { mutableStateOf<BlockedCall?>(null) }

    // Aplicar filtro
    val filteredCalls = remember(blockedCalls, selectedFilter) {
        when (selectedFilter) {
            HistoryFilter.ALL -> blockedCalls
            HistoryFilter.BLOCKED -> blockedCalls.filter { it.wasBlocked }
            HistoryFilter.ALLOWED -> blockedCalls.filter { !it.wasBlocked }
            HistoryFilter.SPAM -> blockedCalls.filter { it.isEffectivelySpam() }
            HistoryFilter.LEGITIMATE -> blockedCalls.filter { it.isEffectivelyLegitimate() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // ═══════════════════════════════════════════════════════════════════
        // TÍTULO Y ESTADÍSTICAS
        // ═══════════════════════════════════════════════════════════════════
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Historial",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            // Contador de spam bloqueado
            val spamCount = blockedCalls.count { it.wasBlocked }
            if (spamCount > 0) {
                Surface(
                    color = Color(0xFFEF4444).copy(alpha = 0.1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "🛡️ $spamCount bloqueadas",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFEF4444),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ═══════════════════════════════════════════════════════════════════
        // FILTROS
        // ═══════════════════════════════════════════════════════════════════

        SingleChoiceSegmentedButtonRow(
            modifier = Modifier.fillMaxWidth()
        ) {
            HistoryFilter.entries.forEachIndexed { index, filter ->
                SegmentedButton(
                    selected = selectedFilter == filter,
                    onClick = { selectedFilter = filter },
                    shape = SegmentedButtonDefaults.itemShape(
                        index = index,
                        count = HistoryFilter.entries.size
                    ),
                    label = {
                        Text(
                            text = "${filter.emoji} ${filter.displayName}",
                            maxLines = 1
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ═══════════════════════════════════════════════════════════════════
        // LISTA DE LLAMADAS
        // ═══════════════════════════════════════════════════════════════════

        if (filteredCalls.isEmpty()) {
            // Estado vacío
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = when (selectedFilter) {
                            HistoryFilter.ALL -> "📋"
                            HistoryFilter.BLOCKED -> "🛡️"
                            HistoryFilter.ALLOWED -> "✅"
                            HistoryFilter.SPAM -> "🚫"
                            HistoryFilter.LEGITIMATE -> "👤"
                        },
                        style = MaterialTheme.typography.displayLarge
                    )

                    Text(
                        text = when (selectedFilter) {
                            HistoryFilter.ALL -> "No hay llamadas registradas"
                            HistoryFilter.BLOCKED -> "No hay llamadas bloqueadas"
                            HistoryFilter.ALLOWED -> "No hay llamadas permitidas"
                            HistoryFilter.SPAM -> "No hay spam detectado"
                            HistoryFilter.LEGITIMATE -> "No hay llamadas legítimas"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Text(
                        text = "Las llamadas analizadas aparecerán aquí",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(
                    items = filteredCalls,
                    key = { it.id }
                ) { call ->
                    CallHistoryCard(
                        call = call,
                        onClick = { selectedCall = call },
                        onCallBack = { onCallBack(call) }
                    )
                }

                // Espaciado final
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // DIÁLOGO DE DETALLES
    // ═══════════════════════════════════════════════════════════════════════

    selectedCall?.let { call ->
        CallDetailDialog(
            call = call,
            onDismiss = { selectedCall = null },
            onCallBack = {
                onCallBack(call)
                selectedCall = null
            },
            onMarkAsSpam = {
                onMarkAsSpam(call)
                selectedCall = null
            },
            onMarkAsLegitimate = {
                onMarkAsLegitimate(call)
                selectedCall = null
            }
        )
    }
}

/**
 * Tarjeta individual de llamada en el historial
 */
@Composable
private fun CallHistoryCard(
    call: BlockedCall,
    onClick: () -> Unit,
    onCallBack: () -> Unit
) {
    val categoryColor = try {
        Color(call.getCategoryColor().toColorInt())
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (call.wasBlocked) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ═══════════════════════════════════════════════════════════════
            // EMOJI DE CATEGORÍA
            // ═══════════════════════════════════════════════════════════════

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(categoryColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = call.getCategoryEmoji(),
                    style = MaterialTheme.typography.titleLarge
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // ═══════════════════════════════════════════════════════════════
            // INFORMACIÓN DE LA LLAMADA
            // ═══════════════════════════════════════════════════════════════

            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Nombre o número
                Text(
                    text = call.getDisplayName(),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Categoría
                Text(
                    text = call.getCategoryDisplayName(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = categoryColor,
                    maxLines = 1
                )

                // Tiempo relativo y acción
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = call.getRelativeTime(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )

                    if (call.wasBlocked) {
                        Surface(
                            color = Color(0xFFEF4444).copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Bloqueada",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFEF4444),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (call.wasUserCorrected()) {
                        Surface(
                            color = Color(0xFF3B82F6).copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Corregida",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF3B82F6),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // ═══════════════════════════════════════════════════════════════
            // BOTONES DE ACCIÓN
            // ═══════════════════════════════════════════════════════════════

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Botón llamar
                IconButton(
                    onClick = onCallBack,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Llamar",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                // Botón "Saber más"
                TextButton(
                    onClick = onClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Saber más...",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

/**
 * Diálogo de detalles de la llamada - "Saber más..."
 */
@Composable
private fun CallDetailDialog(
    call: BlockedCall,
    onDismiss: () -> Unit,
    onCallBack: () -> Unit,
    onMarkAsSpam: () -> Unit,
    onMarkAsLegitimate: () -> Unit
) {
    val categoryColor = try {
        Color(call.getCategoryColor().toColorInt())
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // ═══════════════════════════════════════════════════════════
                // CABECERA
                // ═══════════════════════════════════════════════════════════

                Surface(
                    color = categoryColor.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Emoji grande
                        Text(
                            text = call.getCategoryEmoji(),
                            style = MaterialTheme.typography.displayMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Categoría
                        Text(
                            text = call.getCategoryDisplayName(),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )

                        // Descripción corta
                        Text(
                            text = call.getCategoryShortDescription(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Info de la llamada
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Número
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "📞",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = call.contactName ?: call.phoneNumber,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Fecha
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "📅",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = call.getFormattedDate(),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            // Confianza
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "📊",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = call.getConfidencePercent(),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }

                // ═══════════════════════════════════════════════════════════
                // CONTENIDO SCROLLABLE
                // ═══════════════════════════════════════════════════════════

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Acción tomada
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (call.wasBlocked) {
                                Color(0xFFEF4444).copy(alpha = 0.1f)
                            } else {
                                Color(0xFF10B981).copy(alpha = 0.1f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (call.wasBlocked) "🛡️" else "🔔",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Acción tomada",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = call.getActionTakenText(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Palabras clave detectadas
                    val keywords = call.getKeywordsList()
                    if (keywords.isNotEmpty()) {
                        Text(
                            text = "🔑 Palabras clave detectadas",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            keywords.forEach { keyword ->
                                Surface(
                                    color = categoryColor.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text(
                                        text = keyword,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = categoryColor,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    Divider()

                    // Explicación detallada
                    Text(
                        text = "📖 Explicación detallada",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = call.getDetailedExplanation(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    // Corrección del usuario
                    if (call.wasUserCorrected()) {
                        Divider()

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFF3B82F6).copy(alpha = 0.1f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "✏️", style = MaterialTheme.typography.titleLarge)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Clasificación corregida",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Text(
                                        text = "Tú marcaste esta llamada como: ${call.userCorrectedCategory?.displayName}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                // ═══════════════════════════════════════════════════════════
                // BOTONES DE ACCIÓN
                // ═══════════════════════════════════════════════════════════

                Divider()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Cerrar
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cerrar")
                    }

                    // Marcar como spam/legítima
                    if (call.isEffectivelyLegitimate()) {
                        Button(
                            onClick = onMarkAsSpam,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFEF4444)
                            )
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Es spam")
                        }
                    } else {
                        Button(
                            onClick = onMarkAsLegitimate,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF10B981)
                            )
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Es legítima")
                        }
                    }

                    // Llamar
                    Button(
                        onClick = onCallBack,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Llamar")
                    }
                }
            }
        }
    }
}

/**
 * FlowRow para mostrar chips de keywords
 */
@Composable
private fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    // Implementación simple de FlowRow usando Layout
    // En producción, usar la de accompanist o material3
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        verticalArrangement = verticalArrangement
    ) {
        content()
    }
}
